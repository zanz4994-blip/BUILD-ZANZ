module.exports = {
  GITHUB_TOKEN: "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",
  GITHUB_OWNER: "zanz4994-blip",
  GITHUB_REPO: "BUILD-ZANZ"
};
