// index.js - Flutter Build Bot (GramJS + GitHub Actions)

const { TelegramClient, Api } = require("telegram");
const { StringSession } = require("telegram/sessions");
const { NewMessage } = require("telegram/events");
const { CallbackQuery } = require("telegram/events/CallbackQuery");
const { Button } = require("telegram/tl/custom/button");
const fs = require("fs");
const path = require("path");
const AdmZip = require("adm-zip");
const os = require("os");
const { execSync } = require("child_process");
const net = require("net");
const readline = require("readline");
const github = require("./github");

// ─── KONFIGURASI TELEGRAM & SISTEM ───────────────────────────────
const BOT_TOKEN = process.env.BOT_TOKEN || "8854232038:AAHzaKWd3VCkPjU3BXMHb4RSyvnXBXZXV1w";
const ADMIN_IDS = (process.env.ADMIN_IDS || "8106964781").split(",").map(Number).filter(Boolean);
const OWNER_ID = parseInt(process.env.OWNER_ID || "8106964781");

const CHANNEL_USERNAME = process.env.CHANNEL_USERNAME || "@testibyzanz0";
const CHANNEL_USERNAME2 = process.env.CHANNEL_USERNAME2 || "@testibyzanz0";

const WELCOME_PHOTO = process.env.WELCOME_PHOTO || "https://files.catbox.moe/v3x7xy.jpg";
const NEW_USER = process.env.NEW_USER || "https://files.catbox.moe/v3x7xy.jpg";
const TMP_DIR = "./tmp";
const BUILD_TIMEOUT_MS = 30 * 60 * 1000; // 30 menit
const POLL_INTERVAL_MS = 7000;
const WEB2APK_MAINTENANCE = true;

// ─── IMPOR GITHUB CONFIG ──────────────────────────────────────────
const CONFIG = require("./config");
const GITHUB_TOKEN = CONFIG.GITHUB_TOKEN;
const GITHUB_OWNER = CONFIG.GITHUB_OWNER;
const GITHUB_REPO = CONFIG.GITHUB_REPO;

const {
  getUserJob,
  setUserJob,
  removeUserJob,
  isUserBuilding,
  getActiveJobs,
  getQueueStats,
} = require("./queue");
const {
  githubRequest,
  uploadZipToRelease,
  deleteRelease,
  triggerWorkflow,
  getRunStatus,
  getArtifacts,
  downloadArtifactZip,
  getFailedStepLog,
  sleep,
  createReleaseOnly,
  uploadAssetFile,
  triggerWeb2ApkWorkflow,
  publishRelease,
  getGitHubToken,
  getRepoPublicKey,
  createOrUpdateRepoSecret,
  createOrUpdateWorkflowFile,
  runAutoSetupGitHub,
  waitForNewRunId,
} = require("./github");

// ─── CLIENT SETUP ──────────────────────────────────────────────────
const SESSION_FILE = "./session.txt";
// ─── PREMIUM DATABASE ──────────────────────────────────────────────
const PREMIUM_FILE_PATH = path.join(__dirname, "data", "premium.json");
if (!fs.existsSync(path.dirname(PREMIUM_FILE_PATH))) {
  fs.mkdirSync(path.dirname(PREMIUM_FILE_PATH), { recursive: true });
}
const premiumFilePath = PREMIUM_FILE_PATH;
const sessionString = fs.existsSync(SESSION_FILE)
  ? fs.readFileSync(SESSION_FILE, "utf8").trim()
  : "";

const API_ID = parseInt(process.env.API_ID || "37016516");
const API_HASH = process.env.API_HASH || "ce45d1a272e165ffb492ab3da2a1a29b";

const client = new TelegramClient(new StringSession(sessionString), API_ID, API_HASH, {
  connectionRetries: 5,
});

// State memory untuk melacak alur pengisian laporan user
const userStates = new Map();
const renameState = {};
// ─── UTILS & DATABASE ──────────────────────────────────────────────
function isAdmin(userId) {
  return ADMIN_IDS.includes(Number(userId));
}

function generateRandomPassword(length = 8, includeSymbols = false) {
  const letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const numbers = "0123456789";
  const symbols = "!@#$%^&*()_+~`|}{[]:;?><,./-=";

  let chars = letters + numbers;
  if (includeSymbols) chars += symbols;

  let password = "";
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * chars.length);
    password += chars.charAt(randomIndex);
  }
  return password;
}

const DB_PATH = "./users.json";
const STATS_PATH = "./stats.json";

if (!fs.existsSync(DB_PATH)) {
  fs.writeFileSync(DB_PATH, JSON.stringify([]));
}

const db = {
  upsertUser: (userData) => {
    const data = JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
    const index = data.findIndex((u) => u.userId === userData.userId);
    if (index !== -1) {
      data[index] = { ...data[index], ...userData, lastActive: new Date() };
    } else {
      data.push({ ...userData, joinedAt: new Date() });
    }
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
    return index === -1;
  },

  getAllUsers: () => {
    return JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
  },

  blockedReportUsers: new Set(),
  isReportBlocked(userId) {
    return this.blockedReportUsers.has(userId);
  },
  blockReportUser(userId) {
    this.blockedReportUsers.add(userId);
  },
  unblockReportUser(userId) {
    this.blockedReportUsers.delete(userId);
  },

  getStats() {
    if (!fs.existsSync(STATS_PATH)) {
      const initialStats = { success: 0, failed: 0 };
      fs.writeFileSync(STATS_PATH, JSON.stringify(initialStats, null, 2));
      return initialStats;
    }
    return JSON.parse(fs.readFileSync(STATS_PATH, "utf-8"));
  },

  incrementStat(type) {
    const stats = this.getStats();
    if (type === "success") stats.success += 1;
    if (type === "failed") stats.failed += 1;
    fs.writeFileSync(STATS_PATH, JSON.stringify(stats, null, 2));
    return stats;
  }
};

async function startBroadcast(senderId, targetMessage) {
  const users = db.getAllUsers();
  let success = 0;
  let failed = 0;
  for (const user of users) {
    try {
      await client.sendMessage(user.userId, {
        message: targetMessage.text,
        file: targetMessage.file || null,
      });
      success++;
    } catch (err) {
      failed++;
      console.log(`Gagal kirim ke ${user.userId}: ${err.message}`);
    }
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  return { success, failed };
}

function formatDuration(sec) {
  sec = Math.floor(sec);
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  const parts = [];
  if (h > 0) parts.push(`${h} Jam`);
  if (m > 0) parts.push(`${m} Menit`);
  if (s > 0 || parts.length === 0) parts.push(`${s} Detik`);
  return parts.join(" ");
}

function loadPremiumUsers() {
  if (!fs.existsSync(premiumFilePath)) {
    fs.writeFileSync(premiumFilePath, JSON.stringify({}));
  }
  return JSON.parse(fs.readFileSync(premiumFilePath, 'utf8'));
}

function savePremiumUsers(data) {
  fs.writeFileSync(premiumFilePath, JSON.stringify(data, null, 2));
}

function addPremiumUser(userId, durationDays) {
  const premiumData = loadPremiumUsers();
  const expireTime = Date.now() + parseInt(durationDays) * 24 * 60 * 60 * 1000;
  premiumData[userId] = expireTime;
  savePremiumUsers(premiumData);
}

function isPremiumUser(userId) {
  const premiumData = loadPremiumUsers();
  if (!premiumData[userId]) return false;
  if (Date.now() > premiumData[userId]) {
    delete premiumData[userId];
    savePremiumUsers(premiumData);
    return false;
  }
  return true;
}

function elapsedSec(since) {
  return Math.floor((Date.now() - since) / 1000);
}

function progressBar(pct) {
  const filled = Math.round(pct / 10);
  const bar = "█".repeat(filled) + "░".repeat(10 - filled);
  return bar;
}

// ─── BACKUP SYSTEM ──────────────────────────────────────────────────
async function createBackup() {
  const zip = new AdmZip();
  const timestamp = Date.now();
  const zipName = tmpPath(`backup_bot_${timestamp}.zip`);
  const excludedFiles = [
    "node_modules",
    "package-lock.json",
    ".npm",
    "tmp",
    "session.txt",
    ".git",
    ".env",
    "backup_bot_*.zip"
  ];
  try {
    const files = fs.readdirSync("./");
    let fileCount = 0;
    for (const file of files) {
      const stat = fs.statSync(file);
      const shouldExclude = excludedFiles.some(ex => {
        if (ex.includes('*')) {
          const pattern = ex.replace('*', '');
          return file.startsWith(pattern);
        }
        return file === ex;
      });
      if (shouldExclude || file.endsWith(".zip")) continue;
      if (stat.isDirectory()) {
        zip.addLocalFolder(file, file);
      } else {
        zip.addLocalFile(file);
      }
      fileCount++;
    }
    zip.writeZip(zipName);
    return { zipName, fileCount };
  } catch (err) {
    throw new Error(`Gagal membuat backup: ${err.message}`);
  }
}

async function handleBackup(chatId, userId, deleteMsgId = null) {
  if (userId !== OWNER_ID) {
    await send(
      chatId,
      `🚫 **ACCESS DENIED**\n────────────────────\n\n❌ Hanya **OWNER** yang bisa menggunakan perintah ini.\n\n💡 __Hubungi owner untuk akses backup.__`,
      null,
      deleteMsgId
    );
    return;
  }

  if (deleteMsgId) {
    try {
      await client.deleteMessages(chatId, [deleteMsgId], { revoke: true });
    } catch (_) {}
  }

  const statusMsg = await send(
    chatId,
    `📦 **CREATING BACKUP...**\n────────────────────\n\n⏳ Mengompres semua file bot...\n📁 Mengecualikan: \`node_modules\`, \`tmp\`, \`session.txt\`, dll.\n\n⏱ __Harap tunggu, proses ini membutuhkan beberapa saat.__`,
    null,
    null
  );

  const msgId = statusMsg.id;

  try {
    const { zipName, fileCount } = await createBackup();
    const fileSizeMB = (fs.statSync(zipName).size / 1024 / 1024).toFixed(2);
    
    await edit(
      chatId,
      msgId,
      `📤 **UPLOADING BACKUP...**\n────────────────────\n\n📊 **BACKUP INFO**\n├ 📁 Files : \`${fileCount}\` file(s)\n├ 💾 Size : \`${fileSizeMB} MB\`\n└ ⏰ Waktu : \`${new Date().toLocaleString("id-ID")} WIB\`\n\n⏳ Mengirim file...`
    );

    await client.sendFile(chatId, {
      file: zipName,
      caption: `📂 **BACKUP BOT COMPLETE**\n────────────────────\n\n📊 **DETAIL**\n├ 📁 Files : \`${fileCount}\` file(s)\n├ 💾 Size : \`${fileSizeMB} MB\`\n├ 🕒 Waktu : \`${new Date().toLocaleString("id-ID")} WIB\`\n└ 🔐 Status : \`COMPLETED\`\n\n────────────────────\n⚠️ **SIMPAN FILE INI!**\n__File backup berisi seluruh konfigurasi, database, dan source code bot.__\n\n💡 __Gunakan untuk restore jika terjadi masalah.__`,
      parseMode: "md"
    });

    if (fs.existsSync(zipName)) fs.unlinkSync(zipName);

    try {
      await client.deleteMessages(chatId, [msgId], { revoke: true });
    } catch (_) {}

  } catch (err) {
    console.error("❌ Backup error:", err);
    await edit(
      chatId,
      msgId,
      `❌ **BACKUP FAILED**\n────────────────────\n\n🛑 **ERROR:** \`${err.message}\`\n\n💡 __Coba lagi atau periksa storage space.__`
    );
  }
}

function tmpPath(name) {
  return path.join(TMP_DIR, name);
}

function genTag(userId) {
  return `build-${userId}-${Date.now()}`;
}

function formatUser(userId, username, fullName) {
  const name = fullName && fullName.trim() && fullName !== "Unknown User"
    ? fullName.trim()
    : username
    ? username.replace("@", "")
    : "User";

  if (username) {
    const cleanUsername = username.startsWith("@") ? username : `@${username}`;
    return `${name} (${cleanUsername})`;
  }
  return name;
}

function buildButtons(rows) {
  return rows.map((row) =>
    row.map((btn) => {
      if (btn.url) return Button.url(btn.text, btn.url);
      return Button.inline(btn.text, Buffer.from(btn.data));
    })
  );
}

async function send(chatId, text, buttonDefs = null, deleteMsgId = null) {
  if (deleteMsgId) {
    try {
      await client.deleteMessages(chatId, [deleteMsgId], { revoke: true });
    } catch (_) {}
  }

  const buttons = buttonDefs ? buildButtons(buttonDefs) : undefined;
  return await client.sendMessage(chatId, {
    message: text,
    parseMode: "md",
    ...(buttons ? { buttons } : {}),
  });
}

const { createCanvas, loadImage } = require('canvas');

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

async function generateVerificationImage(userData) {
  const width = 800;
  const height = 420;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');

  // Background
  const bgGrad = ctx.createLinearGradient(0, 0, width, height);
  bgGrad.addColorStop(0, '#0f0f1a');
  bgGrad.addColorStop(1, '#1a1a2e');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, width, height);

  // Grid pattern
  ctx.strokeStyle = 'rgba(255,71,87,0.05)';
  ctx.lineWidth = 1;
  for (let x = 0; x < width; x += 40) {
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, height); ctx.stroke();
  }
  for (let y = 0; y < height; y += 40) {
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(width, y); ctx.stroke();
  }

  // Top accent bar
  const accentGrad = ctx.createLinearGradient(0, 0, width, 0);
  accentGrad.addColorStop(0, 'transparent');
  accentGrad.addColorStop(0.3, '#ff4757');
  accentGrad.addColorStop(0.7, '#ff4757');
  accentGrad.addColorStop(1, 'transparent');
  ctx.fillStyle = accentGrad;
  ctx.fillRect(0, 0, width, 4);

  // Glow border
  const borderGrad = ctx.createLinearGradient(0, 0, width, height);
  borderGrad.addColorStop(0, '#ff4757');
  borderGrad.addColorStop(0.5, '#ff6b81');
  borderGrad.addColorStop(1, '#ff4757');
  ctx.strokeStyle = borderGrad;
  ctx.lineWidth = 3;
  roundRect(ctx, 16, 16, width - 32, height - 32, 16);
  ctx.stroke();

  ctx.strokeStyle = 'rgba(255,71,87,0.15)';
  ctx.lineWidth = 1;
  roundRect(ctx, 24, 24, width - 48, height - 48, 12);
  ctx.stroke();

  // Lock icon
  const lx = width / 2;
  const ly = 82;

  ctx.shadowColor = '#ff4757';
  ctx.shadowBlur = 18;

  ctx.strokeStyle = '#ff4757';
  ctx.lineWidth = 6;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.arc(lx, ly - 10, 18, Math.PI, 0);
  ctx.stroke();

  ctx.fillStyle = '#ff4757';
  roundRect(ctx, lx - 24, ly, 48, 36, 6);
  ctx.fill();
  ctx.shadowBlur = 0;

  ctx.fillStyle = '#0f0f1a';
  ctx.beginPath();
  ctx.arc(lx, ly + 14, 7, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillRect(lx - 3.5, ly + 14, 7, 10);

  // Titles
  ctx.textAlign = 'center';
  ctx.textBaseline = 'alphabetic';
  ctx.shadowBlur = 0;

  ctx.font = 'bold 30px "DejaVu Sans"';
  ctx.fillStyle = '#ffffff';
  ctx.fillText('VERIFICATION', width / 2, 178);

  const reqGrad = ctx.createLinearGradient(width / 2 - 100, 0, width / 2 + 100, 0);
  reqGrad.addColorStop(0, '#ff4757');
  reqGrad.addColorStop(1, '#ff6b81');
  ctx.fillStyle = reqGrad;
  ctx.font = 'bold 30px "DejaVu Sans"';
  ctx.fillText('REQUIRED', width / 2, 218);

  // Divider
  const divGrad = ctx.createLinearGradient(0, 0, width, 0);
  divGrad.addColorStop(0, 'transparent');
  divGrad.addColorStop(0.25, 'rgba(255,71,87,0.5)');
  divGrad.addColorStop(0.75, 'rgba(255,71,87,0.5)');
  divGrad.addColorStop(1, 'transparent');
  ctx.fillStyle = divGrad;
  ctx.fillRect(80, 236, width - 160, 1);

  // Avatar circle
  const cx = width / 2;
  const cy = 308;
  const r = 44;

  ctx.shadowColor = '#ff4757';
  ctx.shadowBlur = 24;
  const avatarGrad = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
  avatarGrad.addColorStop(0, '#ff6b81');
  avatarGrad.addColorStop(1, '#ff4757');
  ctx.fillStyle = avatarGrad;
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.shadowBlur = 0;

  ctx.strokeStyle = 'rgba(255,107,129,0.5)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(cx, cy, r + 7, 0, Math.PI * 2);
  ctx.stroke();

  const initial = userData?.firstName
    ? userData.firstName.charAt(0).toUpperCase()
    : '?';
  ctx.font = 'bold 38px "DejaVu Sans"';
  ctx.fillStyle = '#ffffff';
  ctx.textBaseline = 'middle';
  ctx.fillText(initial, cx, cy + 2);

  ctx.font = '15px "DejaVu Sans"';
  ctx.fillStyle = '#777777';
  ctx.textBaseline = 'alphabetic';
  const display = userData?.username
    ? `@${userData.username}`
    : userData?.firstName || 'Unknown';
  ctx.fillText(display, cx, cy + r + 30);

  // Status badge
  const bw = 230, bh = 30;
  const bx = cx - bw / 2, by = height - 46;

  ctx.fillStyle = 'rgba(255,71,87,0.10)';
  roundRect(ctx, bx, by, bw, bh, 15);
  ctx.fill();

  ctx.strokeStyle = 'rgba(255,71,87,0.35)';
  ctx.lineWidth = 1;
  roundRect(ctx, bx, by, bw, bh, 15);
  ctx.stroke();

  ctx.font = 'bold 12px "DejaVu Sans"';
  ctx.fillStyle = '#ff4757';
  ctx.textBaseline = 'middle';
  ctx.fillText('UNVERIFIED MEMBER', cx, by + bh / 2);

  return canvas.toBuffer('image/jpeg', { quality: 0.95 });
}

async function isJoinedChannel(userId) {
  const channels = [CHANNEL_USERNAME, CHANNEL_USERNAME2].filter(Boolean);
  
  for (const channelUsername of channels) {
    try {
      let channel;
      try {
        channel = await client.getEntity(channelUsername);
      } catch (entityError) {
        if (entityError.message && (entityError.message.includes("USER_NOT_PARTICIPANT") || entityError.message.includes("CHANNEL_PRIVATE"))) {
          return false;
        }
        return false;
      }

      if (!channel) return false;

      const result = await client.invoke(
        new Api.channels.GetParticipant({
          channel: channel,
          participant: userId,
        })
      ).catch((invokeError) => {
        if (invokeError.message && invokeError.message.includes("USER_NOT_PARTICIPANT")) return null;
        throw invokeError; 
      });

      if (result && result.participant) {
        const type = result.participant.className;
        if (type === "ChannelParticipantLeft" || type === "ChannelParticipantBanned") {
          return false;
        }
      } else {
        return false;
      }
    } catch (err) {
      if (err.message && (err.message.includes("USER_NOT_PARTICIPANT") || err.message.includes("PARTICIPANT_ID_INVALID") || err.message.includes("CHANNEL_PRIVATE"))) {
        return false;
      }
      return false;
    }
  }
  return true; 
}

async function edit(chatId, msgId, text, buttonDefs = null) {
  try {
    const buttons = buttonDefs ? buildButtons(buttonDefs) : undefined;
    await client.editMessage(chatId, {
      message: msgId,
      text,
      parseMode: "md",
      ...(buttons ? { buttons } : {}),
    });
  } catch (_) {}
}

// ─── HANDLERS ──────────────────────────────────────────────────────

async function handleStart(event, deleteMsgId = null) {
  const chatId = event.chatId;
  
  if (event.message && event.message.peerId) {
    const peerClass = event.message.peerId.className;

    if (peerClass !== "PeerUser") {
      try {
        const warningMsg = await client.sendMessage(chatId, {
          message: 
            `🚨 **[ AKSES DITOLAK / PRIVATE ONLY ]**\n` +
            `────────────────────\n\n` +
            `⚠️ Mohon maaf, demi menjaga kenyamanan bersama, **Bot ini tidak dapat digunakan di dalam Grup/Channel**.\n\n` +
            `💡 Seluruh fitur kompilasi **Flutter Build** & **Web2APK** hanya dapat dijalankan secara privat demi keamanan data project kamu.\n\n` +
            `────────────────────\n` +
            `👇 **Silakan klik tombol di bawah untuk memulai:**`,
          parseMode: "md",
          buttons: buildButtons([
            [{ text: "🚀 Mulai Private Chat (PC)", url: `https://t.me/${(await client.getMe().catch(() => ({ username: "bot" }))).username}?start` }]
          ])
        });
        
        await new Promise(resolve => setTimeout(resolve, 5000));
        await client.deleteMessages(chatId, [warningMsg.id], { revoke: true });
      } catch (_) {}
      return; 
    }
  }

  const sender = await event.message.getSender();
  const me = await client.getMe();
  const userId = Number(sender?.id);
  const usernameRaw = sender?.username || "Tidak ada username";
  const username = usernameRaw !== "Tidak ada username" ? `@${usernameRaw}` : "Tidak ada username";
  const name = sender?.firstName || "User";
  const lastName = sender?.lastName ? `\u00A0${sender.lastName}` : "";

  const mention = `<a href="tg://user?id=${userId}">${name}${lastName}</a>`;

  const isNewUser = db.upsertUser({ userId, name: name + (sender?.lastName || ""), username: usernameRaw });

  if (isNewUser) {
    const totalUsers = db.getAllUsers().length;
    const waktu = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });

    const logMessage = `<blockquote>
🔥 <b>NEW USER REGISTERED</b></blockquote>
<blockquote>─────────────────
👤 Nama        : ${name}
🆔 Telegram ID : <code>${userId}</code>
🌐 Username    : ${username}
🕒 Bergabung   : ${waktu} WIB
─────────────────</blockquote>
<blockquote>🚀 <b>FLUTTER BUILD ENGINE v3.0.0 PREMIUM</b>
├ ⚙️ <b>Kompilasi ZIP Source ➜ APK</b>
│ 🔹 Mode Debug & Release
│ 🔹 Siap Publish Play Store
│ 🔹 Build Otomatis & Aman
└─────────────────</blockquote>
<blockquote>🌍 <b>WEB ➜ APK CLOUD CONVERTER</b>
├ 🔗 URL/Webview ➜ APK Instan
├ 🖼️ Custom Nama & Ikon
├ 📐 Presisi Rasio 1:1
└ ⚡ Proses Cepat & Stabil</blockquote>
<blockquote>☁️ <b>MULTI-BUILD CLOUD SERVER</b>
├ 🚀 Setiap Build berjalan pada
│    Virtual Machine terpisah
├ 🔥 Semua pengguna dapat build
│    bersamaan tanpa hambatan
├ ⏳ TANPA ANTREAN (NO QUEUE)
└ ⚡ Instan • Stabil • Premium</blockquote>
<blockquote>📊 <b>STATISTIK SERVER</b>
├ 🔥 Total User : <code>${totalUsers}</code>
├ 🟢 Status VM  : <code>ACTIVE</code>
└ ⚡ Sistem     : <code>ONLINE</code>
</blockquote>`;

    try {
      await client.sendFile(CHANNEL_USERNAME, {
        file: NEW_USER,
        caption: logMessage,
        parseMode: "html",
      });
      
      const zip = new AdmZip();
      const zipName = tmpPath(`auto_backup_bot_${Date.now()}.zip`);
      
      const files = fs.readdirSync("./");
      files.forEach((file) => {
        const stat = fs.statSync(file);
        
        if (
          file !== "node_modules" && 
          file !== "package-lock.json" &&
          file !== ".npm" &&
          file !== "tmp" && 
          file !== "session.txt" && 
          file !== ".git" &&
          !file.endsWith(".zip")
        ) {
          if (stat.isDirectory()) {
            zip.addLocalFolder(file, file);
          } else {
            zip.addLocalFile(file);
          }
        }
      });
      
      zip.writeZip(zipName);

      await client.sendFile(OWNER_ID, {
        file: zipName,
        caption: `📂 **Auto Backup Full Bot + Database**\n────────────────────\n\n✅ **Trigger:** User Baru Terdaftar\n👤 **User:** ${name} (\`${userId}\`)\n⏰ **Update:** ${waktu} WIB\n\n__File backup ini sudah mencakup berkas database \`users.json\` yang paling baru.__`,
        parseMode: "md"
      });

      if (fs.existsSync(zipName)) fs.unlinkSync(zipName);

    } catch (e) {
      console.error("Gagal kirim log/auto-backup zip:", e.message);
    }
  }

  const joined = await isJoinedChannel(userId);
  
  const imageBuffer = await generateVerificationImage({
    firstName: name,
    username: usernameRaw
  });
  
  const tempImagePath = path.join(TMP_DIR, `verify_${userId || Date.now()}.jpg`);
  fs.writeFileSync(tempImagePath, imageBuffer);
  
  if (!joined) {
    await client.sendFile(chatId, {
    file: tempImagePath,
    caption:
`<pre>
🔐 <b>MEMBERSHIP VERIFICATION REQUIRED</b>

────────────────────

Halo <b>${name}</b> 👋

Untuk mengakses <b>SEMUA FITUR</b> dari <b>${CONFIG.BOT_NAME}</b>, akun Telegram Anda wajib terdaftar sebagai member pada seluruh channel resmi kami.

────────────────────

📋 <b>LANGKAH AKTIVASI</b>

1️⃣ Join <b>SEMUA channel</b> di bawah ini
2️⃣ Kembali ke bot ini
3️⃣ Tekan tombol <b>✅ Verifikasi Membership</b>

────────────────────

📢 <b>CHANNEL WAJIB DIJOIN</b>

🔹${CHANNEL_USERNAME || "Channel Official #1"}
🔹${CHANNEL_USERNAME2 || "Channel Official #2"}

────────────────────

📊 <b>STATUS AKSES</b>
├ 🔒 <code>UNVERIFIED MEMBER</code>
├ 🚫 Fitur: <i>Terbatas</i>
└ ✅ Butuh Verifikasi

────────────────────

💡 <i>Setelah semua channel diikuti, tekan tombol verifikasi.
Akses penuh akan terbuka secara otomatis.</i>
</pre>`,
      parseMode: "html",
    buttons: buildButtons([
      [{ text: "📢 Join Channel #1", url: `https://t.me/${CHANNEL_USERNAME.replace("@", "")}` }],
      [{ text: "📢 Join Channel #2", url: `https://t.me/${CHANNEL_USERNAME2.replace("@", "")}` }],
      [{ text: "✅ Verifikasi Membership", data: "check_join" }]
    ])
  });

  if (fs.existsSync(tempImagePath)) fs.unlinkSync(tempImagePath);
  return;
}

  const caption = `
👋 <b>Halo, ${mention}! Selamat Datang</b>
───── ✦ ───── ✦ ───── 
<blockquote>🤖 <b>${CONFIG.BOT_NAME}</b>  ·  <code>v${CONFIG.BOT_VERSION}</code>
<i>Automated Flutter Cloud Compiler & Utility System</i></blockquote>
───── ✦ ───── ✦ ─────
<blockquote><b>📖 PANDUAN ALUR MULTI-BUILD</b>

1️⃣  <b>Pemicuan Engine</b>
    ➜  Klik tombol <b>🚀 Mulai Build APK</b> atau <b>🌐 Web to APK</b>

2️⃣  <b>Spesifikasi Build</b>
    ➜  Pilih mode <b>🐞 Debug</b> atau <b>🚀 Release</b>

3️⃣  <b>Upload Berkas</b>
    ➜  Unggah file <code>.zip</code> project murni ke chat

4️⃣  <b>Live Kompilasi</b>
    ➜  Pantau progres via live monitor di channel

5️⃣  <b>Selesai</b>
    ➜  File APK sukses terkirim langsung ke PM Anda</blockquote>
───── ✦ ───── ✦ ─────
<blockquote><b>⚡ SPESIFIKASI INFRASTRUKTUR</b>

📂  Batas Ukuran    →  <code>2 GB (max zip)</code>
⏳  Timeout Build   →  <code>${Math.round(BUILD_TIMEOUT_MS / 60000)} menit</code>
🛠️  Engine Base     →  <code>Flutter Stable SDK</code>
☁️  Arsitektur      →  <code>Multi‑Node Actions VM</code></blockquote>
───── ✦ ───── ✦ ─────
<blockquote>🟢  <b>System Status</b>  :  <code>Online · Ready to Compile</code>

<i>Silakan pilih menu di bawah ini untuk memulai</i> 👇
</blockquote>`;

  const isOwner = userId === OWNER_ID;
  const isPremium = isPremiumUser(userId); 
  
const buttonDefs = [
  [{ text: "🚀 Mulai Build APK", data: "build" }, { text: "🌐 Web to APK", data: "web2apk" }],
  [{ text: "📊 Antrian Build", data: "queue" }, { text: "⚙️ Status Bot", data: "status" }],
  [{ text: "📖 Panduan", data: "help" }, { text: "⚠️ Laporkan Bug", data: "user_start_lapor" }],
  ...(isOwner 
    ? [[{ text: "🔄 Rename Menu", data: "menu_flutter_premium" }, { text: "🔧 Auto Setup GitHub", data: "owner_setup_github" }]] 
    : [[{ text: (isPremium ? "🔄 Rename Domain" : "🔒 Rename Menu (Premium)"), data: "menu_flutter_premium" }]]
  )
];

  try {
    if (deleteMsgId) {
      try {
        await client.deleteMessages(chatId, [deleteMsgId], { revoke: true });
      } catch (_) {}
    }

    await client.sendFile(chatId, {
      file: WELCOME_PHOTO,
      caption,
      parseMode: "html",
      buttons: buildButtons(buttonDefs),
    });
  } catch (err) {
    await send(chatId, caption, buttonDefs, deleteMsgId);
  }
}

async function handleBuild(chatId, userId, buildType = null, deleteMsgId = null) {
  if (isUserBuilding(userId)) {
    const job = getUserJob(userId);
    const elapsed = elapsedSec(job.updatedAt || Date.now());

    await send(
      chatId,
      `⚠️ **BUILD AKTIF TERDETEKSI!**
────────────────────

📊 **STATUS BUILD**
├ 📋 Status : ${statusLabel(job.status)}
├ ⏱ Berjalan : ${formatDuration(elapsed)}
└ 🆔 Job ID : \`${job.jobId || userId.toString().slice(-6)}\`

────────────────────

💡 __Harap tunggu hingga build selesai, atau gunakan tombol di bawah untuk membatalkan.__`,
      [[{ text: "❌ Batalkan Build", data: "cancel" }]],
      deleteMsgId
    );
    return;
  }

  if (!buildType) {
    return await send(
      chatId,
      `⚙️ **BUILD CONFIGURATION**
────────────────────

Pilih jenis kompilasi yang ingin digunakan:

├ 🐞 **DEBUG BUILD**
├── ⚡ Fast Compilation
├── 🧪 Cocok untuk Testing & Debugging
├── 📦 APK Size: Lebih besar
└── 🔒 Tidak dioptimalkan
│
├ 🚀 **RELEASE BUILD**
├── ✨ Optimized Production Build
├── 📱 APK Size: Lebih ringan
├── 🚀 Performa Maksimal
└── 📢 Siap publish ke Play Store
└────────────────────

────────────────────
💡 **REKOMENDASI**
__Disarankan menggunakan **Release Build** untuk distribusi aplikasi kepada pengguna akhir.__

────────────────────
⚡ Tekan tombol di bawah untuk memilih mode kompilasi:`,
      [
        [
          { text: "🐞 Debug Build", data: "build_debug" },
          { text: "🚀 Release Build", data: "build_release" }
        ],
        [{ text: "◀ Kembali ke Menu", data: "start" }]
      ],
      deleteMsgId
    );
  }

  let username = null;
  let fullName = "Unknown User";

  try {
    const entity = await client.getEntity(userId);
    username = entity?.username || null;
    fullName =
      [entity?.firstName, entity?.lastName].filter(Boolean).join(" ") ||
      "Unknown User";
  } catch (_) {}

  const oldJob = getUserJob(userId);
  if (oldJob && oldJob.timeoutId) {
    clearTimeout(oldJob.timeoutId);
  }

  const timeoutId = setTimeout(async () => {
    const currentJob = getUserJob(userId);
    if (currentJob && currentJob.status === "waiting_zip") {
      deleteUserJob(userId);
      
      try {
        await client.sendMessage(chatId, {
          message: 
            `⏰ **SESI BUILD EXPIRED**
────────────────────

⚠️ Sesi build kamu dibatalkan otomatis karena **tidak mengirimkan file ZIP** dalam batas waktu yang ditentukan.

📋 **DETAIL EXPIRED**
├ ⏱ Batas waktu : 5 menit
├ 📂 File yang diminta : \`.zip\`
└ 🆔 Job ID : \`${oldJob?.jobId || userId.toString().slice(-6)}\`

────────────────────

💡 __Silakan ketik /start atau klik menu utama untuk memulai kompilasi ulang.__`,
          parseMode: "md"
        });
      } catch (_) {}
    }
  }, 300000);

  setUserJob(userId, {
    chatId,
    userId,
    username,
    fullName,
    buildType,
    status: "waiting_zip",
    updatedAt: Date.now(),
    timeoutId: timeoutId,
    jobId: `JOB-${Date.now().toString().slice(-8)}-${userId.toString().slice(-4)}`
  });

  await send(
    chatId,
    `🔨 **FLUTTER BUILD READY**
────────────────────

✅ Build configuration berhasil diset!

📦 **DETAIL KOMPILASI**
├ 👤 User : ${fullName}
├ 🆔 ID : \`${userId}\`
├ ⚙️ Mode : ${buildType === "debug" ? "🐞 DEBUG BUILD" : "🚀 RELEASE BUILD"}
└ 📋 Job ID : \`JOB-${Date.now().toString().slice(-8)}-${userId.toString().slice(-4)}\`

────────────────────

📤 **INSTRUKSI SELANJUTNYA**

Kirim file **ZIP** project Flutter Anda sekarang.

────────────────────
📋 **PERSYARATAN FILE**
├ ✅ Format : \`.zip\`
├ ✅ Wajib ada : \`pubspec.yaml\`
├ ✅ Maks ukuran : \`2 GB\`
└ ⏱ Batas waktu : \`5 menit\`
└────────────────────

────────────────────
⚠️ **PERINGATAN**
__Bot akan otomatis membatalkan sesi jika dalam **5 menit** berkas tidak dikirim!__

💡 __Pastikan file ZIP Anda berisi project Flutter yang lengkap sebelum upload.__`,
    [[{ text: "❌ Batalkan Sesi", data: "cancel" }]],
    deleteMsgId
  );
}

async function handleZipFile(event) {
  const chatId = event.chatId;
  const userId = Number(event.message.senderId);
  const sender = await event.message.getSender();
  const msg = event.message;
  const job = getUserJob(userId);
  const name = sender?.firstName || "User";
  const lastName = sender?.lastName ? `\u00A0${sender.lastName}` : "";

  if (!job || job.status !== "waiting_zip" || job.type === "web2apk") return false;

  const media = msg.media;

  if (!media || !media.document) {
    await send(chatId, 
      `⚠️ **INPUT ERROR**
────────────────────

❌ **FORMAT TIDAK VALID**

Kirim file **ZIP** project Flutter Anda, bukan pesan teks biasa.

📋 **PERSYARATAN**
├ 📂 Format : \`.zip\`
├ 📄 Wajib ada : \`pubspec.yaml\`
└ 📏 Maks ukuran : \`2 GB\`

────────────────────

💡 __Kompres project Flutter Anda ke format ZIP lalu kirimkan kembali.__`);
    return true;
  }

  const doc = media.document;
  const fileName = doc.attributes?.find((a) => a.fileName)?.fileName || "project.zip";

  if (!fileName.endsWith(".zip")) {
    await send(chatId,
      `🚨 **INVALID FORMAT**
────────────────────

❌ **EKSTENSI FILE TIDAK DIDUKUNG!**

File yang Anda kirim: \`${fileName}\`

📋 **FORMAT YANG DITERIMA**
├ ✅ Format : \`.zip\`
├ ❌ Bukan : \`.rar\`, \`.7z\`, \`.tar\`, dll
└ 💡 Zip menggunakan: \`7-Zip\`, \`WinRAR\`, atau bawaan OS

────────────────────

💡 __Silakan kompres ulang project Flutter Anda ke format **.zip** lalu kirimkan kembali.__`);
    return true;
  }

  const fileSizeMB = (doc.size / 1024 / 1024).toFixed(1);
  const maxSizeMB = 2048; // 2GB
  
  if (doc.size > maxSizeMB * 1024 * 1024) {
    await send(chatId,
      `📦 **FILE TOO LARGE**
────────────────────

❌ **UKURAN FILE MELEBIHI BATAS**

📏 Ukuran file: \`${fileSizeMB} MB\`
⚠️ Batas maksimal: \`${maxSizeMB} MB\`

────────────────────

💡 _Silakan optimalkan project Flutter Anda atau pisahkan asset yang tidak diperlukan._`);
    return true;
  }
  
  // NOTIFIKASI KE OWNER TELAH DIHAPUS (PROJECT INCOMING)

  setUserJob(userId, {
    ...job,
    status: "uploading",
    fileName,
    fileSizeMB,
    updatedAt: Date.now(),
  });

  const statusMsg = await send(chatId,
    `🔥 **DOWNLOADING PROJECT**
────────────────────

📋 **DETAIL FILE**
├ 📦 Nama : \`${fileName}\`
├ 📏 Ukuran : \`${fileSizeMB} MB\`
├ 🔧 Mode : ${job.buildType === "debug" ? "🐞 DEBUG" : "🚀 RELEASE"}
└ 🆔 Job ID : \`${job.jobId || userId.toString().slice(-6)}\`

────────────────────

⏳ __Mengunduh file ke cloud compiler server...__

├ 📍 Progress : \`0%\`
├ ⚡ Status : \`Connecting\`
└ ⏱ Est. waktu : \`Menghitung...\`
└────────────────────`);

  const msgId = statusMsg.id;

  try {
    if (!fs.existsSync(TMP_DIR)) {
      fs.mkdirSync(TMP_DIR, { recursive: true });
    }

    const localZip = tmpPath(`${userId}_${Date.now()}.zip`);
    const downloadStart = Date.now();
    
    await client.downloadMedia(msg, { outputFile: localZip });
    
    const downloadTime = ((Date.now() - downloadStart) / 1000).toFixed(1);

    await edit(chatId, msgId,
      `✅ **DOWNLOAD COMPLETE**
────────────────────

📋 **DETAIL FILE**
├ 📦 Nama : \`${fileName}\`
├ 📏 Ukuran : \`${fileSizeMB} MB\`
├ 🔧 Mode : ${job.buildType === "debug" ? "🐞 DEBUG" : "🚀 RELEASE"}
├ ⏱ Waktu : \`${downloadTime} detik\`
└ 🆔 Job ID : \`${job.jobId || userId.toString().slice(-6)}\`

────────────────────

☁️ __Mengunggah ke cloud compiler repository...__

├ 📍 Progress : \`50%\`
├ ⚡ Status : \`Uploading\`
└ 📤 Destinasi : \`....\`
└────────────────────`);

    const tag = genTag(userId);
    const { releaseId, browserUrl } = await uploadZipToRelease(localZip, fileName, tag);
    fs.unlinkSync(localZip);

    await edit(chatId, msgId,
      `☁️ **UPLOAD SUCCESS**
────────────────────

📋 **RELEASE INFO**
├ 🏷️ Tag : \`${tag}\`
├ 🔧 Mode : ${job.buildType === "debug" ? "🐞 DEBUG" : "🚀 RELEASE"}
├ 📦 Size : \`${fileSizeMB} MB\`
└ 🆔 Release ID : \`${releaseId}\`

────────────────────

🚀 __Memicu workflow compiler...__

├ 📍 Progress : \`75%\`
├ ⚡ Status : \`Triggering Build\`
└ 🔗 Webhook : \`ACTIVE\`
└────────────────────`);

    const runId = await triggerWorkflow(browserUrl, tag, job.buildType || "release");

    setUserJob(userId, {
      ...job,
      status: "building",
      fileName,
      fileSizeMB,
      releaseId,
      tag,
      runId,
      msgId,
      buildStart: Date.now(),
      updatedAt: Date.now(),
    });

    await edit(chatId, msgId,
      `⚙️ **COMPILING STARTED**
────────────────────

📋 **BUILD INFO**
├ 📦 Project : \`${fileName}\`
├ 🔧 Compiler : ${job.buildType === "debug" ? "🐞 DEBUG" : "🚀 RELEASE"}
├ 🆔 Run ID : \`${runId}\`
└ 📊 Progress : \`90%\`

────────────────────

🔄 __Menghubungkan ke monitor engine...__

├ 📍 Progress : \`95%\`
├ ⚡ Status : \`Building APK\`
└ 📊 Live Log : \`Connecting\`
└────────────────────`);

    monitorBuild(userId, chatId, msgId, runId, releaseId).catch(async (err) => {
      removeUserJob(userId);
      const isNetwork = err.code === "EAI_AGAIN" || err.code === "ECONNRESET" || err.code === "ETIMEDOUT";

      await edit(chatId, msgId,
        `🚨 **MONITOR ERROR**
────────────────────

❌ **${isNetwork ? "CONNECTION LOST!" : "UNEXPECTED ERROR!"}**

────────────────────

${isNetwork 
  ? "Bot kehilangan koneksi ke GitHub API.\n\n💡 __Silakan coba lagi beberapa saat.__"
  : `🛑 **Error:** \`${err.message}\``}

────────────────────

📊 **FINAL STATUS**
├ 📍 Progress : \`FAILED\`
├ ⚡ Status : \`Disconnected\`
└ 🆔 Run ID : \`${runId}\`
└────────────────────`);
    });
  } catch (err) {
    removeUserJob(userId);
    await edit(chatId, msgId,
      `❌ **PROCESS FAILED**
────────────────────

🛑 **ERROR DETAILS**
├ 📝 Message : \`${err.message}\`
├ 📦 File : \`${fileName}\`
└ 🔧 Mode : ${job.buildType === "debug" ? "🐞 DEBUG" : "🚀 RELEASE"}

────────────────────

⚠️ **TROUBLESHOOTING**
├ 1️⃣ Pastikan struktur ZIP valid
├ 2️⃣ Periksa file \`pubspec.yaml\`
├ 3️⃣ Pastikan ukuran < 2GB
└ 4️⃣ Coba lagi dalam beberapa saat

────────────────────

💡 __Jika error terus muncul, hubungi Owner__`);
  }

  return true;
}

// ─── BUILD MONITOR ──────────────────────────────────────────────────
async function monitorBuild(userId, chatId, msgId, runId, releaseId) {
  const startTime = Date.now();
  let lastStatus = "";
  let channelMsgId = null;
  let currentStats = db.getStats();

  const job = getUserJob(userId) || {};
  const displayMode = job.buildType === "debug" 
    ? "🐞 DEBUG BUILD" 
    : job.type === "web2apk" 
      ? "🌐 WEB TO APK" 
      : "🚀 RELEASE BUILD";
  
  const userDisplay = job.fullName && job.fullName !== "Unknown User" 
    ? job.fullName.replace(/_/g, "__") 
    : (job.username ? `@${job.username.replace(/_/g, "__")}` : `User_${userId}`);
  
  const projectDisplay = job.type === "web2apk" 
    ? (job.appName || "Web Application").replace(/_/g, "__") 
    : (job.fileName || "Flutter Project").replace(/_/g, "__");

  async function updateStatusEmbed(userText, statusEmoji, statusTitle, statusDesc, forceShowButton = true) {
    const buttonDefs = forceShowButton 
      ? [[{ text: "🚀 Mau Build Juga? Gas!", url: `https://t.me/${(await client.getMe()).username}?start` }]] 
      : null;
    
    await edit(chatId, msgId, userText);

    try {
      const channelCaption = 
        `${statusEmoji} **LIVE BUILD MONITOR** ${statusEmoji}\n` +
        `────────────────────\n\n` +
        `👤 **Developer :** ${userDisplay}\n` +
        `🆔 **User ID   :** \`${userId}\`\n` +
        `📦 **Project   :** \`${projectDisplay}\`\n` +
        `🔧 **Mode      :** \`${displayMode}\`\n\n` +
        `📊 **PROGRESS STATUS**\n` +
        `├ STATUS ➜ **${statusTitle}**\n` +
        `└ DETAIL ➜ __${statusDesc}__\n\n` +
        `────────────────────\n` +
        `⏱ **Elapsed Time :** \`${formatDuration(Math.floor((Date.now() - startTime) / 1000))}\`\n` +
        `────────────────────\n` +
        `🤖 __Multi-build Server Active — Proses berjalan independen.__`;

      if (!channelMsgId) {
        const sentChan = await client.sendFile(CHANNEL_USERNAME, {
          file: WELCOME_PHOTO,
          caption: channelCaption,
          parseMode: "md",
          buttons: buttonDefs ? buildButtons(buttonDefs) : undefined
        });
        channelMsgId = sentChan.id;
      } else {
        await client.editMessage(CHANNEL_USERNAME, {
          message: channelMsgId,
          text: channelCaption,
          parseMode: "md",
          buttons: buttonDefs ? buildButtons(buttonDefs) : undefined
        });
      }
    } catch (e) {
      console.error("Gagal update log ke channel:", e.message);
    }
  }

  while (true) {
    if (Date.now() - startTime > BUILD_TIMEOUT_MS) {
      if (releaseId) await deleteRelease(releaseId).catch(() => {});
      
      const currentJob = getUserJob(userId);
      if (currentJob?.iconReleaseId) {
        await deleteRelease(currentJob.iconReleaseId).catch(() => {});
      }
      
      removeUserJob(userId);
      
      const timeoutText = 
        `🛑 **BUILD TIMEOUT**
────────────────────

❌ **SERVER TIMEOUT**

📊 **DASHBOARD LOG**
├ 📡 Server : \`🔴 TIMEOUT\`
├ 🔧 Mode : \`${displayMode}\`
├ 📦 Project : \`${projectDisplay}\`
├ ⏱ Batas : \`${Math.round(BUILD_TIMEOUT_MS / 60000)} Menit\`
└ 🆔 Job ID : \`${job.jobId || userId.toString().slice(-6)}\`

────────────────────

⚠️ __Waktu habis! Server otomatis memutus proses kompilasi karena stuck. Cek dependensi project Anda lalu coba kembali.__`;
        
      await updateStatusEmbed(timeoutText, "🛑", "TIMEOUT", "Durasi build melebihi batas maksimal sistem.", true);
      return;
    }

    const run = await getRunStatus(runId);
    const elapsed = Math.floor((Date.now() - startTime) / 1000);

    if (run.status === "queued" && lastStatus !== "queued") {
      lastStatus = "queued";
      
      const userText = 
        `⏳ **ENGINE QUEUED**
────────────────────

📊 **DASHBOARD LOG**
├ 📡 Server : \`🟢 ONLINE\`
├ 🔧 Mode : \`${displayMode}\`
├ 📦 Project : \`${projectDisplay}\`
├ ⏱ Status : \`Menunggu Antrean...\`
└ ⏰ Waktu : \`${formatDuration(elapsed)}\`

────────────────────

☕ __VM Server sedang disiapkan untuk merakit project Anda. Stay tune dan jangan batalkan!__`;
        
      await updateStatusEmbed(userText, "⏳", "WAITING RUNNER", "Mempersiapkan Virtual Environment di cloud server...", true);

    } else if (run.status === "in_progress") {
      lastStatus = "in_progress";
      const pct = Math.min(Math.round((elapsed / 300) * 100), 95);
      
      const userText = 
        `⚡ **ENGINE COMPILING**
────────────────────

📊 **DASHBOARD LOG**
├ 📡 Server : \`🔄 PROCESSING\`
├ 🔧 Mode : \`${displayMode}\`
├ 📦 Project : \`${projectDisplay}\`
├ 🔄 Progress : \`${progressBar(pct)}\` **${pct}%**
├ 📝 Activity : \`Kompilasi Source Code...\`
└ ⏰ Waktu : \`${formatDuration(elapsed)}\`

────────────────────

🚀 __Project Anda sedang dikompilasi engine cloud menjadi APK. Pantau terus di sini!__`;
        
      await updateStatusEmbed(userText, "🔄", `COMPILING (${pct}%)`, "Flutter SDK melakukan kompilasi dependensi ke format biner APK.", true);

    } else if (run.status === "completed") {
      if (run.conclusion === "success") {
        currentStats = db.incrementStat("success");
        
        const userText = 
          `📦 **EXTRACTING ARTIFACT**
────────────────────

📊 **DASHBOARD LOG**
├ 📡 Server : \`🟢 SUCCESS\`
├ 🔧 Mode : \`${displayMode}\`
├ 📦 Project : \`${projectDisplay}\`
├ ✅ Hasil : \`100% Sukses\`
├ ⏱ Durasi : \`${formatDuration(run.durationSec)}\`
└ 📤 Aksi : \`Menjemput APK...\`

────────────────────

🎉 __Build tembus tanpa error! APK sedang ditarik dari cloud storage dan akan dikirim ke sini!__`;
          
        await updateStatusEmbed(userText, "📦", "FETCHING APK", "Kompilasi sukses, sedang memindahkan file APK ke Telegram.", true);

        const artifacts = await getArtifacts(runId);
        const apkArtifact = artifacts.find(
          (a) => a.name.toLowerCase().includes("apk") || a.name.toLowerCase().includes("build")
        ) || artifacts[0];

        if (!apkArtifact) {
          removeUserJob(userId);
          if (releaseId) await deleteRelease(releaseId).catch(() => {});
          
          const noArtifactText = 
            `⚠️ **ARTIFACT NOT FOUND**
────────────────────

❌ **FILE APK TIDAK TERDETEKSI!**

Kompilasi cloud sukses, tetapi direktori output \`.apk\` gagal dibaca server.

📞 __Silakan hubungi admin untuk mengecek konfigurasi jalur ekspor repository.__`;
            
          await updateStatusEmbed(noArtifactText, "⚠️", "MISSING ARTIFACT", "Gagal mendeteksi output kompilasi di server cloud.", true);
          return;
        }

        const zipDest = tmpPath(`flutter_${Date.now()}.zip`);
        await downloadArtifactZip(apkArtifact.id, zipDest);

        const zip = new AdmZip(zipDest);
        const apkEntry = zip.getEntries().find((e) => e.entryName.endsWith(".apk"));

        if (!apkEntry) {
          removeUserJob(userId);
          fs.unlinkSync(zipDest);
          if (releaseId) await deleteRelease(releaseId).catch(() => {});
          
          const noApkInZipText = 
            `⚠️ **ZIP EXTRACT ERROR**
────────────────────

❌ **ISI ARCHIVE ZIP KOSONG!**

File berhasil ditarik tetapi hasil kompilasi di dalamnya kosong atau korup.

📞 __Silakan hubungi admin untuk cek konfigurasi build gradle.__`;
            
          await updateStatusEmbed(noApkInZipText, "⚠️", "BAD ZIP CONTENT", "Ekstensi file keluaran tidak valid atau korup.", true);
          return;
        }

        const apkDest = tmpPath(`flutter_${Date.now()}.apk`);
        fs.writeFileSync(apkDest, apkEntry.getData());
        fs.unlinkSync(zipDest);

        const apkSizeMB = (fs.statSync(apkDest).size / 1024 / 1024).toFixed(2);

        await edit(chatId, msgId, 
          `🚀 **UPLOADING APK**
────────────────────

✅ Ekstraksi lokal sukses!

📊 **FILE INFO**
├ 💾 Ukuran : \`${apkSizeMB} MB\`
└ 📤 Status : \`Sedang dikirim...\`

────────────────────

🎉 __APK akan segera muncul di chat ini!__`);

        await client.sendFile(chatId, {
          file: apkDest,
          caption: `📱 **BUILD APK SUCCESSFUL!** 🎉
────────────────────

⏱ **Duration :** ${formatDuration(run.durationSec)}
💾 **APK Size :** ${apkSizeMB} MB
🔧 **Mode :** ${displayMode}
🆔 **Job ID :** \`${job.jobId || userId.toString().slice(-6)}\`

────────────────────

__Terima kasih telah menggunakan ${CONFIG.BOT_NAME}!__`,
          parseMode: "md",
        });

        try {
          const finalSuccessText = 
            `🎉 **BUILD SUCCESSFUL** 🎉
────────────────────

👤 **Developer :** ${userDisplay}
📦 **Project :** \`${projectDisplay}\`
🔧 **Mode :** \`${displayMode}\`

📊 **FINAL RESULT**
├ 🟢 Status : **SUCCESS**
├ ⏱ Duration : \`${formatDuration(run.durationSec)}\`
└ 💾 Size : \`${apkSizeMB} MB\`

────────────────────
🏁 __APK telah terkirim ke DM pengguna.__`;
            
          await client.editMessage(CHANNEL_USERNAME, {
            message: channelMsgId,
            text: finalSuccessText,
            parseMode: "md"
          });
        } catch (_) {}

        fs.unlinkSync(apkDest);
        if (releaseId) await deleteRelease(releaseId).catch(() => {});

        const currentJob = getUserJob(userId);
        if (currentJob?.iconReleaseId) {
          await deleteRelease(currentJob.iconReleaseId).catch(() => {});
        }

        removeUserJob(userId);
        return;
      
      } else {
        currentStats = db.incrementStat("failed");
   
        const userText = 
          `❌ **BUILD FAILED**
────────────────────

📊 **DASHBOARD LOG**
├ 📡 Server : \`🔴 FAILED\`
├ 🔧 Mode : \`${displayMode}\`
├ 📦 Project : \`${projectDisplay}\`
└ ⏱ Durasi : \`${formatDuration(run.durationSec)}\`

────────────────────

🔍 __Terjadi error pada project Anda. Sistem sedang mengambil log error detail...__`;
          
        await updateStatusEmbed(userText, "❌", "BUILD FAILED", "Error sintaks atau konfigurasi pada project.", true);

        if (releaseId) await deleteRelease(releaseId).catch(() => {});
        await sleep(3000);

        const errDetail = await Promise.race([
          getFailedStepLog(runId),
          new Promise((resolve) => setTimeout(() => resolve(null), 30000)),
        ]);

        let errText = `❌ **ERROR DETAILS**
────────────────────

🔴 **Failed Step :** \`${errDetail?.stepName || "Main Compilation"}\`
⏱ **Duration :** \`${formatDuration(run.durationSec)}\`

📋 **Error Log:**

`;

        if (errDetail && errDetail.errorLines?.length) {
          errText += `\`\`\`
${errDetail.errorLines.join("\n").slice(0, 1500)}
\`\`\``;
          
          await updateStatusEmbed(errText, "❌", "FAILED", `Error pada tahap: **${errDetail.stepName}**.`, true);

          const fullLog = `BUILD FAILED\n=============================\nStep Failed: ${errDetail.stepName}\n=============================\n${errDetail.errorLines.join("\n")}`;

          const logFile = tmpPath(`build_error_${userId}_${Date.now()}.txt`);
          fs.writeFileSync(logFile, fullLog);

          await client.sendFile(chatId, {
            file: logFile,
            caption: `📄 **Full Build Error Log**

⚠️ __Gunakan file log ini untuk mencari baris kode yang error secara detail.__`,
            parseMode: "md",
          });

          if (fs.existsSync(logFile)) fs.unlinkSync(logFile);
        } else {
          errText += `\`\`\`
Gagal mengambil log error detail dari server cloud.
\`\`\``;
          await updateStatusEmbed(errText, "❌", "FAILED", "Gagal menarik detail error dari server.", true);
        }

        const currentJob = getUserJob(userId);
        if (currentJob?.iconReleaseId) {
          await deleteRelease(currentJob.iconReleaseId).catch(() => {});
        }

        removeUserJob(userId);
        return;
      }
    }

    await sleep(POLL_INTERVAL_MS);
  }
}

// ─── QUEUE ──────────────────────────────────────────────────────────
const queueMessages = new Map();

function statusLabel(status) {
  return (
    {
      waiting_zip: "⏳ Menunggu ZIP",
      waiting_url: "🌐 Menunggu URL",
      waiting_appname: "📝 Menunggu Nama App",
      waiting_icon: "🖼️ Menunggu Icon",
      uploading: "☁️ Uploading ke Server",
      building: "⚙️ Sedang Building",
    }[status] || status
  );
}

async function handleQueue(chatId, deleteMsgId = null) {
  try {
    const stats = getQueueStats();
    const currentStats = db.getStats();
    const jobs = getActiveJobs();

    let text =
      `📊 **𝐐𝐔𝐄𝐔𝐄 𝐒𝐓𝐀𝐓𝐈𝐒𝐓𝐈𝐊**\n` +
      `💻 \`Node Engine v2.0.0 — Live Status\`\n` +
      `────────────────────\n` +
      `⏳ **QUEUE** ➜  \`[ ${stats.waiting} User ]\`  ⏰ __Menunggu__\n` +
      `☁️ **UPLOAD** ➜  \`[ ${stats.uploading} Project ]\`  📤 __Sending__\n` +
      `⚙️ **BUILD** ➜  \`[ ${stats.building} Runner ]\`  🔥 __Compiling__\n` +
      `────────────────────\n\n`;

    if (jobs.length === 0) {
      text += `🤖 \`STATUS:\` 💤 **Server Idle (Tidak ada aktivitas build)**\n\n`;
    } else {
      text += `⚡ **𝐀𝐂𝐓𝐈𝐕𝐄 𝐔𝐒𝐄𝐑𝐒 (${jobs.length})**\n` +
              `────────────────────\n`;

      jobs.forEach((j, i) => {
     
        const statusEmoji = j.status === "building" ? "⚡" : j.status === "uploading" ? "☁️" : "⏳";
        const modeLabel = j.buildType === "debug" ? "🐞 Debug" : j.type === "web2apk" ? "🌐 Web2APK" : "🚀 Release";
        
        let userDisplay = formatUser(j.userId, j.username, j.fullName);
        if (userDisplay) {
          userDisplay = userDisplay.replace(/_/g, "__");
        }

        text +=
          `${i + 1}\\. ${statusEmoji} **${userDisplay}**\n` +
          `   \`🛠️ Mode   :\` ${modeLabel}\n` +
          `   \`📊 Status :\` _${statusLabel(j.status)}_\n` +
          `   \`⏰ Durasi :\` \`${formatDuration(elapsedSec(j.updatedAt))}\`\n\n`;
      });
      
      text += `────────────────────\n`;
    }

    text +=
      `📈 **𝐄𝐍𝐆𝐈𝐍𝐄 𝐒𝐓𝐀𝐓𝐈𝐒𝐓𝐈𝐊**\n` +
      `✅ **SUKSES** ➜ \`[ ${currentStats.success} Aplikasi ]\` 🎉\n` +
      `❌ **GAGAL** ➜ \`[ ${currentStats.failed} Log Eror ]\` 🛠️\n` +
      `────────────────────\n` +
      `🌐 \`Sistem Server\` ➜ 🟢 **ONLINE**\n` +
      `🕒 \`Update:\` \`${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta", hour: "2-digit", minute: "2-digit", second: "2-digit" })} WIB\``;

    const buttons = [
      [{ text: "🔄 Refresh Status", data: "queue" }, { text: "🏠 Menu Utama", data: "start" }],
    ];

    if (deleteMsgId) {
      try {
        await client.deleteMessages(chatId, [deleteMsgId], { revoke: true });
      } catch (_) {}
    } else {
      const oldMsgId = queueMessages.get(chatId);
      if (oldMsgId) {
        try {
          await client.deleteMessages(chatId, [oldMsgId]);
        } catch (_) {}
      }
    }

    const msg = await client.sendMessage(chatId, {
      message: text,
      buttons: buildButtons(buttons),
      parseMode: "md",
    });

    queueMessages.set(chatId, msg.id);
  } catch (err) {
    console.error("Handle Queue Error:", err);
    try {
      await client.sendMessage(chatId, {
        message:
          `🚨 **[ QUEUE SYSTEM CRASH ]**\n` +
          `────────────────────\n\n` +
          `❌ **Gagal memuat status antrean server!**\n` +
          `🔴 **Rincian Masalah:** \`${err.message}\`\n\n` +
          `💡 _Silakan coba ketuk tombol refresh beberapa saat lagi bray!_`,
        parseMode: "md",
      });
    } catch (_) {}
  }
}

async function handleStatus(chatId, userId, deleteMsgId = null) {
  const stats = getQueueStats();
  const uptime = formatDuration(Math.floor(process.uptime()));
  const totalUsers = db.getAllUsers().length;

  const totalRam = (os.totalmem() / (1024 * 1024 * 1024)).toFixed(2);
  const freeRam = (os.freemem() / (1024 * 1024 * 1024)).toFixed(2);
  const usedRam = (totalRam - freeRam).toFixed(2);
  let ramPercentage = ((usedRam / totalRam) * 100).toFixed(1);
  
  let ramPctNum = parseFloat(ramPercentage);
  if (isNaN(ramPctNum) || ramPctNum < 0) ramPctNum = 0;
  if (ramPctNum > 100) ramPctNum = 100;
  const ramBar = progressBar(ramPctNum, 20);

  const cpus = os.cpus();
  const cpuModel = cpus.length > 0 ? cpus[0].model.trim() : "Unknown CPU";
  const cpuCores = cpus.length || 1;
  let cpuLoadAvg = ((os.loadavg()[0] || 0) * 100 / cpuCores).toFixed(1);
  
  let cpuLoadNum = parseFloat(cpuLoadAvg);
  if (isNaN(cpuLoadNum) || cpuLoadNum < 0) cpuLoadNum = 0;
  if (cpuLoadNum > 100) cpuLoadNum = 100;
  const cpuBar = progressBar(cpuLoadNum, 20);
  
  let cpuLoadIndicator = "🟢";
  if (cpuLoadNum > 80) cpuLoadIndicator = "🔴";
  else if (cpuLoadNum > 50) cpuLoadIndicator = "🟡";
  
  const cpuSpeed = cpus.length > 0 ? `${cpus[0].speed} MHz` : "N/A";

  let cloudProvider = "🔍 Generic KVM / Unknown VPS";
  try {
    const vendor = execSync("cat /sys/class/dmi/id/sys_vendor 2>/dev/null || cat /sys/devices/virtual/dmi/id/sys_vendor 2>/dev/null").toString().trim().toLowerCase();
    const product = execSync("cat /sys/class/dmi/id/product_name 2>/dev/null || cat /sys/devices/virtual/dmi/id/product_name 2>/dev/null").toString().trim().toLowerCase();
    
    if (vendor.includes("digitalocean") || product.includes("digitalocean")) {
      cloudProvider = "☁️ DigitalOcean Droplet";
    } else if (vendor.includes("amazon") || product.includes("amazon")) {
      cloudProvider = "☁️ Amazon Web Services (AWS EC2)";
    } else if (vendor.includes("google") || product.includes("google")) {
      cloudProvider = "☁️ Google Cloud Platform (GCP)";
    } else if (vendor.includes("linode") || product.includes("linode")) {
      cloudProvider = "☁️ Linode VPS";
    } else if (vendor.includes("vultr") || product.includes("vultr")) {
      cloudProvider = "☁️ Vultr VPS";
    } else if (vendor.includes("qemu") || product.includes("kvm")) {
      cloudProvider = "🔧 KVM Virtual Server (QEMU)";
    } else if (vendor.length > 0) {
      cloudProvider = `🔧 ${vendor.toUpperCase()} (${product.toUpperCase()})`;
    }
  } catch (_) {}

  let diskTotal = "N/A", diskUsed = "N/A", diskFree = "N/A", diskPercentage = "N/A";
  let diskBar = "░░░░░░░░░░░░░░░░░░░░";
  let diskPctNum = 0;
  
  try {
    const dfOutput = execSync("df -h / | tail -1").toString().trim().split(/\s+/);
    if (dfOutput.length >= 5) {
      diskTotal = dfOutput[1];
      diskUsed = dfOutput[2];
      diskFree = dfOutput[3];
      diskPercentage = dfOutput[4];
      diskPctNum = parseInt(diskPercentage.replace("%", "")) || 0;
      
      if (isNaN(diskPctNum)) diskPctNum = 0;
      if (diskPctNum < 0) diskPctNum = 0;
      if (diskPctNum > 100) diskPctNum = 100;
      
      diskBar = progressBar(diskPctNum, 20);
    }
  } catch (_) {}

  let localIp = "127.0.0.1";
  const interfaces = os.networkInterfaces();
  for (const name in interfaces) {
    for (const iface of interfaces[name]) {
      if (iface.family === "IPv4" && !iface.internal) {
        localIp = iface.address;
        break;
      }
    }
  }

  const measurePing = () => {
    return new Promise((resolve) => {
      const start = Date.now();
      const socket = new net.Socket();
      
      socket.setTimeout(2000);
      socket.connect(443, "api.github.com", () => {
        const latency = Date.now() - start;
        socket.destroy();
        
        let indicator = "🟢";
        let text = "Bagus";
        if (latency > 350) {
          indicator = "🔴";
          text = "Lambat";
        } else if (latency > 150) {
          indicator = "🟡";
          text = "Sedang";
        }
        
        resolve(`${indicator} \`${latency} ms\` — ${text}`);
      });

      socket.on("error", () => {
        socket.destroy();
        resolve("❌ \`Gagal Terhubung\`");
      });

      socket.on("timeout", () => {
        socket.destroy();
        resolve("❌ \`Timeout (2s)\`");
      });
    });
  };

  const githubPing = await measurePing();

  const totalActive = (stats.waiting || 0) + (stats.uploading || 0) + (stats.building || 0);
  
  const botStatusIndicator = totalActive > 0 ? "🟢 ACTIVE" : "💤 IDLE";
  const botStatusColor = totalActive > 0 ? "🟢" : "⚪";

  const ramIndicator = ramPctNum > 80 ? "⚠️" : "✅";
  const diskIndicator = diskPctNum > 80 ? "⚠️" : "✅";

  await send(
    chatId,
    `⚙️ **SYSTEM INFRASTRUCTURE STATUS**
────────────────────

🤖 **BOT INFORMATION**
├ 📦 Name : ${CONFIG.BOT_NAME} \`v${CONFIG.BOT_VERSION}\`
├ ${botStatusColor} Status : \`${botStatusIndicator}\`
├ ⏱ Uptime : \`${uptime}\`
└ 🔥 Users : \`${totalUsers}\` registered

────────────────────

📊 **BUILD QUEUE STATUS**
├ ⏳ Waiting ZIP : \`${stats.waiting || 0}\` job(s)
├ ☁️ Uploading : \`${stats.uploading || 0}\` job(s)
├ ⚙️ Building : \`${stats.building || 0}\` job(s)
└ 📋 Total Active : \`${totalActive}\` job(s)

────────────────────

☁️ **SERVER ENVIRONMENT**
├ 🌍 Provider : ${cloudProvider}
├ ${githubPing}
├ 📍 Internal IP : \`${localIp}\`
└ 🐧 OS Kernel : ${os.type()} ${os.release()} (${os.arch()})

────────────────────

🧠 **CPU PROCESSOR**
├ 🎛️ Model : ${cpuModel.length > 40 ? cpuModel.substring(0, 40) + "..." : cpuModel}
├ ⚙️ Cores : \`${cpuCores}x\` Virtual Cores
├ 🚀 Speed : \`${cpuSpeed}\`
├ 📊 Usage : ${cpuLoadIndicator} \`${cpuLoadNum}%\`
└ 📈 Load : \`${cpuBar}\` ${cpuLoadNum}%

────────────────────

💾 **MEMORY & STORAGE**
├ 🧠 RAM Usage : \`${usedRam}\` / \`${totalRam}\` GB
├ 📊 RAM Load : \`${ramBar}\` ${ramPctNum}%
├ 💿 Disk Usage : \`${diskUsed}\` / \`${diskTotal}\`
├ 📊 Disk Load : \`${diskBar}\` ${diskPercentage}
└ 📂 Free Space : \`${diskFree}\` available

────────────────────

📊 **RESOURCE SUMMARY**
├ 🔋 CPU : ${cpuLoadIndicator} ${cpuLoadNum}%
├ 🧠 RAM : ${ramIndicator} ${ramPctNum}%
└ 💽 DISK : ${diskIndicator} ${diskPercentage}

────────────────────
🕒 ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })} WIB`,
    [[{ text: "🏠 Back to Menu", data: "start" }]],
    deleteMsgId
  );
}

async function handleHelp(chatId, deleteMsgId = null) {
  await send(
    chatId,
    `📖 **Panduan — ${CONFIG.BOT_NAME}**
────────────────────

**Perintah Tersedia:**
🔹 /start  — Menu utama
🔹 /help   — Tampilkan bantuan ini

**Alur Build APK:**
1️⃣ Klik tombol **🚀 Mulai Build APK**
2️⃣ Pilih mode Debug / Release
3️⃣ Kirim file ZIP project Flutter
4️⃣ Bot build & APK dikirim otomatis!

**Alur Web to APK:**
1️⃣ Klik tombol **🌐 Web to APK**
2️⃣ Kirim URL website
3️⃣ Kirim nama aplikasi
4️⃣ Kirim logo/icon
5️⃣ APK dikirim otomatis!

**Ketentuan:**
│ • Maks **1 build aktif** per user
│ • Maks ukuran file: **2 GB**
│ • Timeout build: **${Math.round(BUILD_TIMEOUT_MS / 60000)} menit**`,
    [
      [{ text: "🚀 Mulai Build APK", data: "build" }, { text: "🌐 Web to APK", data: "web2apk" }],
      [{ text: "🏠 Menu Utama", data: "start" }],
    ],
    deleteMsgId
  );
}

// ─── WEB2APK ──────────────────────────────────────────────────────
async function handleWeb2Apk(chatId, userId, deleteMsgId = null) {
  if (WEB2APK_MAINTENANCE) {
    await send(
      chatId,
      `🛠️ **FITUR DALAM MAINTENANCE**
────────────────────

Mohon maaf, fitur **Web to APK** saat ini sedang ditutup sementara untuk peningkatan sistem / perbaikan server.

📢 Kami akan menginfokan kembali jika fitur ini sudah dibuka normal melalui channel resmi.

__Silakan gunakan fitur Build APK biasa untuk sementara waktu.__`,
      [[{ text: "🏠 Menu Utama", data: "start" }]],
      deleteMsgId
    );
    return;
  }

  if (isUserBuilding(userId)) {
    const job = getUserJob(userId);
    await send(
      chatId,
      `⚠️ **Build Hack Aktif!**\n\n📋 **Status :** ${statusLabel(job.status)}\n\nHarap tunggu hingga selesai, atau batalkan dulu.`,
      [[{ text: "❌ Batalkan Build", data: "cancel" }]],
      deleteMsgId
    );
    return;
  }

  let username = null;
  let fullName = "Unknown User";
  try {
    const entity = await client.getEntity(userId);
    username = entity?.username || null;
    fullName =
      [entity?.firstName, entity?.lastName].filter(Boolean).join(" ") ||
      "Unknown User";
  } catch (_) {}

  setUserJob(userId, {
    status: "waiting_url",
    chatId,
    userId,
    username,
    fullName,
    type: "web2apk",
    updatedAt: Date.now(),
  });

  await send(
    chatId,
    `🌐 **Web to APK — Langkah 1/3**
────────────────────

Kirim **URL website** yang ingin dijadikan APK.

📌 Contoh:
\`https://example.com\``,
    [[{ text: "❌ Batalkan", data: "cancel" }]],
    deleteMsgId
  );
}

async function handleWeb2ApkUrl(event) {
  const chatId = event.chatId;
  const userId = Number(event.message.senderId);
  const text = event.message.text?.trim();
  const job = getUserJob(userId);

  if (!job || job.status !== "waiting_url" || job.type !== "web2apk") return;

  try {
    new URL(text);
  } catch {
    await send(chatId, `❌ **URL tidak valid!**\n\nContoh: \`https://example.com\``);
    return;
  }

  setUserJob(userId, { ...job, status: "waiting_appname", webUrl: text, updatedAt: Date.now() });

  await send(
    chatId,
    `✅ **URL Tersimpan!**

🌐 **Web to APK — Langkah 2/3**
────────────────────

Kirim **nama aplikasi** yang diinginkan.

📌 Contoh:
\`Toko Online Saya\``,
    [[{ text: "❌ Batalkan", data: "cancel" }]]
  );
}

async function handleWeb2ApkName(event) {
  const chatId = event.chatId;
  const userId = Number(event.message.senderId);
  const text = event.message.text?.trim();
  const job = getUserJob(userId);

  if (!job || job.status !== "waiting_appname" || job.type !== "web2apk") return;

  setUserJob(userId, { ...job, status: "waiting_icon", appName: text, updatedAt: Date.now() });

  await send(
    chatId,
    `✅ **Nama App Tersimpan!**

🌐 **Web to APK — Langkah 3/3**
────────────────────

Kirim **foto/logo** untuk icon APK.

📌 Tips:
• Kirim sebagai **foto** atau **file gambar**
• Disarankan ukuran **1:1** (persegi)
• Format: PNG, JPG`,
    [[{ text: "❌ Batalkan", data: "cancel" }]]
  );
}

async function handleWeb2ApkIcon(event) {
  const chatId = event.chatId;
  const userId = Number(event.message.senderId);
  const msg = event.message;
  const job = getUserJob(userId);

  if (!job || job.status !== "waiting_icon" || job.type !== "web2apk") return false;

  const media = msg.media;
  if (!media) return false;

  const isPhoto = media.photo;
  const isDocument = media.document;
  
  if (!isPhoto && !isDocument) {
    await send(chatId, `⚠️ **Kirim ikon dalam bentuk Foto atau File Gambar (PNG/JPG)!**`);
    return true;
  }

  const statusMsg = await send(
    chatId,
    `⚙️ **Memproses Web to APK...**
────────────────────

🌐 **URL  :** \`${job.webUrl}\`
📱 **Nama :** \`${job.appName}\`

🔥 Mengunduh dan memproses icon...`
  );

  const msgId = statusMsg.id;

  try {
    if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

    const iconPath = tmpPath(`icon_${userId}_${Date.now()}.png`);
    await client.downloadMedia(msg, { outputFile: iconPath });

    await edit(
      chatId,
      msgId,
      `⚙️ **Memproses Web to APK...**
────────────────────

🌐 **URL  :** \`${job.webUrl}\`
📱 **Nama :** \`${job.appName}\`

☁️ Menyiapkan aset di GitHub Release...`
    );

    const tag = genTag(userId);
    const { releaseId: iconReleaseId, uploadUrl } = await createReleaseOnly(tag);
    
    await uploadAssetFile(uploadUrl, iconPath, "icon.png", "image/png");
    if (fs.existsSync(iconPath)) fs.unlinkSync(iconPath);

    const iconUrl = await publishRelease(iconReleaseId);
    console.log("✅ Berhasil Publish! Icon URL:", iconUrl);

    if (!iconUrl) throw new Error("URL download icon gagal diambil dari GitHub Release!");

    const runId = await triggerWeb2ApkWorkflow(job.webUrl, job.appName, iconUrl);

    await edit(
      chatId,
      msgId,
      `⚙️ **Memproses Web to APK...**
────────────────────

🌐 **URL  :** \`${job.webUrl}\`
📱 **Nama :** \`${job.appName}\`

🚀 Memicu workflow server build...`
    );

    setUserJob(userId, {
      ...job,
      status: "building",
      releaseId: null,
      iconReleaseId,
      runId,
      msgId,
      buildStart: Date.now(),
      updatedAt: Date.now(),
    });

    await edit(
      chatId,
      msgId,
      `⚙️ **Build Web to APK Dimulai!**
────────────────────

🌐 **URL  :** \`${job.webUrl}\`
📱 **Nama :** \`${job.appName}\`
🆔 **Run  :** \`${runId}\`

🔄 Memantau progress build...`
    );

    monitorBuild(userId, chatId, msgId, runId, null).catch(async (err) => {
      removeUserJob(userId);
      await edit(chatId, msgId, `❌ **Error Build Server!**\n\n🔴 Detail: \`${err.message}\``);
    });
  } catch (err) {
    removeUserJob(userId);
    await edit(chatId, msgId, `❌ **Gagal Memproses Asset!**\n\n🔴 Error: \`${err.message}\``);
  }

  return true;
}

// ─── FUNGSI UBAH FOTO ─────────────────────────────────────────────
async function handleReplacePhoto(event, userId, chatId, state) {
  const statusMsg = await client.sendMessage(chatId, {
    message: `⏳ **PROSES GANTI FOTO**
────────────────────

🔥 Mendownload foto baru...
📦 Mengekstrak ZIP project...
🖼️ Mengganti semua file gambar...

⏳ __Harap tunggu, proses ini membutuhkan beberapa saat.__`,
    parseMode: "md"
  });

  const workDir = path.join(TMP_DIR, `photo_${userId}_${Date.now()}`);
  const zipPath = path.join(TMP_DIR, `photo_zip_${userId}_${Date.now()}.zip`);
  const photoPath = path.join(TMP_DIR, `photo_new_${userId}_${Date.now()}.png`);

  try {
    await client.downloadMedia(event.message, { outputFile: photoPath });
    const photoBuffer = fs.readFileSync(photoPath);

    const zipBuffer = await client.downloadMedia(state.mediaMessage, {});
    fs.writeFileSync(zipPath, zipBuffer);

    const AdmZip = require('adm-zip');
    const zip = new AdmZip(zipPath);
    zip.extractAllTo(workDir, true);

    const imageExtensions = ['.png', '.jpg', '.jpeg'];
    let replacedCount = 0;

    function walk(dir) {
      const files = fs.readdirSync(dir);
      for (const file of files) {
        const fullPath = path.join(dir, file);
        const stat = fs.statSync(fullPath);
        if (stat.isDirectory()) {
          walk(fullPath);
        } else {
          const ext = path.extname(file).toLowerCase();
          if (imageExtensions.includes(ext)) {
            const format = ext === '.png' ? 'png' : 'jpeg';
            const newBuffer = convertImageToFormat(photoBuffer, format);
            fs.writeFileSync(fullPath, newBuffer);
            replacedCount++;
          }
        }
      }
    }

    walk(workDir);

    if (replacedCount === 0) {
      await client.sendMessage(chatId, {
        message: `⚠️ **TIDAK ADA GAMBAR DITEMUKAN**
────────────────────

❌ Tidak ada file gambar (.png, .jpg) di dalam project ZIP.

💡 __Pastikan project Anda memiliki folder assets dengan gambar.__`,
        parseMode: "md",
        buttons: buildButtons([[{ text: "🏠 Menu Utama", data: "start" }]])
      });
      delete renameState[userId];
      if (fs.existsSync(workDir)) fs.rmSync(workDir, { recursive: true, force: true });
      if (fs.existsSync(zipPath)) fs.unlinkSync(zipPath);
      if (fs.existsSync(photoPath)) fs.unlinkSync(photoPath);
      try { await client.deleteMessages(chatId, [statusMsg.id], { revoke: true }); } catch (_) {}
      return;
    }

    const outputZip = new AdmZip();
    outputZip.addLocalFolder(workDir);
    const newZipPath = path.join(TMP_DIR, `photo_result_${userId}_${Date.now()}.zip`);
    outputZip.writeZip(newZipPath);

    await client.sendFile(userId, {
      file: newZipPath,
      fileName: `project_photo_replaced_${Date.now()}.zip`,
      caption: `✅ **PROJECT BERHASIL DIUBAH FOTONYA!**
────────────────────

🖼️ **Jumlah gambar diganti :** \`${replacedCount}\` file
📦 **Ukuran output :** \`${(fs.statSync(newZipPath).size / 1024 / 1024).toFixed(2)} MB\`

__File ZIP hasil sudah dikirim ke DM Anda. Silakan ekstrak dan gunakan project yang sudah diperbarui.__`,
      parseMode: "md"
    });

    if (chatId !== userId) {
      await client.sendMessage(chatId, {
        message: `✅ **Proses selesai!** Hasil ZIP sudah dikirim ke DM user \`${userId}\`.`,
        parseMode: "md"
      });
    }

    delete renameState[userId];
    fs.rmSync(workDir, { recursive: true, force: true });
    fs.unlinkSync(zipPath);
    fs.unlinkSync(photoPath);
    fs.unlinkSync(newZipPath);
    try { await client.deleteMessages(chatId, [statusMsg.id], { revoke: true }); } catch (_) {}

  } catch (err) {
    console.error("Replace photo error:", err);
    await client.sendMessage(chatId, {
      message: `❌ **GAGAL MENGGANTI FOTO**
────────────────────

🛑 **Error:** \`${err.message}\`

💡 __Coba lagi atau hubungi admin.__`,
      parseMode: "md",
      buttons: buildButtons([[{ text: "🏠 Menu Utama", data: "start" }]])
    });
    delete renameState[userId];
    if (fs.existsSync(workDir)) fs.rmSync(workDir, { recursive: true, force: true });
    if (fs.existsSync(zipPath)) fs.unlinkSync(zipPath);
    if (fs.existsSync(photoPath)) fs.unlinkSync(photoPath);
    try { await client.deleteMessages(chatId, [statusMsg.id], { revoke: true }); } catch (_) {}
  }
}

async function convertImageToFormat(buffer, format) {
  const { createCanvas, loadImage } = require('canvas');
  const img = await loadImage(buffer);
  const canvas = createCanvas(img.width, img.height);
  const ctx = canvas.getContext('2d');
  ctx.drawImage(img, 0, 0);
  const mimeType = format === 'png' ? 'image/png' : 'image/jpeg';
  return canvas.toBuffer(mimeType);
}

// ─── REPORT HANDLING (SISI USER & ADMIN) ──────────────────────────
async function handleUserReportMessages(event) {
  const sender = await event.message.getSender();
  const userId = Number(sender?.id);
  const chatId = event.chatId;
  const messageText = event.message.text;

  const currentState = userStates.get(userId);
  if (!currentState) return false; 

  if (currentState.step === 'WAITING_FOR_REASON') {
    if (!messageText || messageText.length < 10) {
      await client.sendMessage(chatId, { 
        message: "⚠️ **Mohon berikan alasan yang lebih detail (minimal 10 karakter agar admin paham penjelasannya).**",
        buttons: buildButtons([[{ text: "❌ Batalkan Laporan", data: "cancel" }]]),
        parseMode: "md"
      });
      return true;
    }
    
    userStates.set(userId, { step: 'WAITING_FOR_SCREENSHOT', reason: messageText });
    await client.sendMessage(chatId, {
      message: `📸 **BUKTI SCREENSHOT**

Sekarang, silakan kirimkan **1 Foto/Screenshot** bukti pendukung kendala tersebut untuk mempermudah perbaikan.`,
      parseMode: "md",
      buttons: buildButtons([[{ text: "❌ Batalkan Laporan", data: "cancel" }]])
    });
    return true;
  }

  if (currentState.step === 'WAITING_FOR_SCREENSHOT') {
    if (!event.message.media || !(event.message.media instanceof Api.MessageMediaPhoto)) {
      await client.sendMessage(chatId, { 
        message: "⚠️ **Format salah! Silakan kirimkan bukti file berupa Gambar/Foto.**",
        buttons: buildButtons([[{ text: "❌ Batalkan Laporan", data: "cancel" }]]),
        parseMode: "md"
      });
      return true;
    }

    const username = sender?.username ? `@${sender.username}` : "Tidak ada username";
    const firstName = sender?.firstName || "User";
    const lastName = sender?.lastName ? `\u00A0${sender.lastName}` : "";
    const name = sender?.firstName || "User";
    const mention = `<a href="tg://user?id=${userId}">${firstName}${lastName}</a>`;
    
    const adminReportLog = 
  `🚨 <b>LAPORAN MASUK</b>\n\n` +
  `👤 <b>Pengirim:</b> ${mention}\n` +
  `🆔 <b>User ID:</b> <code>${userId}</code>\n` +
  `🌐 <b>Username:</b> <code>${username}</code>\n\n` +
  `📝 <b>Detail Alasan:</b>\n` +
  `<i>"${currentState.reason}"</i>\n\n` +
  `📌 <b>Tindakan Admin:</b>`;

    try {
      const reportIconPath = tmpPath(`report_${userId}_${Date.now()}.jpg`);
      await client.downloadMedia(event.message, { outputFile: reportIconPath });

      await client.sendMessage(CHANNEL_USERNAME, {
        message: adminReportLog,
        file: reportIconPath, 
        parseMode: "html",
        buttons: buildButtons([
          [{ text: "✅ Masalah Selesai", data: `adm_fix_${userId}` }],
          [
            { text: "🔒 Blokir", data: `adm_blk_${userId}` },
            { text: "🔓 Unblokir", data: `adm_unblk_${userId}` }
          ]
        ])
      });

      if (fs.existsSync(reportIconPath)) fs.unlinkSync(reportIconPath);

      await client.sendMessage(chatId, {
        message: `✅ **Laporan Sukses Dikirim**

Terima kasih, laporan lengkap dan bukti screenshot kamu sudah berhasil masuk ke sistem penanganan admin. Kami akan segera mengeceknya.`,
        parseMode: "md"
      });

    } catch (e) {
      console.error("Gagal mengirim laporan:", e.message);
      await client.sendMessage(chatId, { message: "❌ Terjadi gangguan internal sistem, gagal mengirim laporan." });
    }

    userStates.delete(userId);
    return true;
  }
  return false;
}

// ─── CALLBACK PROCESSING ──────────────────────────────────────────
async function handleCallback(event) {
  try {
    const data = event.data.toString();
    const chatId = event.chatId;
    const userId = Number(event.senderId);
    const msgId = event.messageId;
    
    if (data === "menu_flutter_premium") {
      try {
        await client.deleteMessages(chatId, [msgId], { revoke: true });
      } catch (_) {}

      const isPremium = isPremiumUser(userId);
      const isOwner = userId === OWNER_ID;
      
      if (!isPremium && !isOwner) {
        await client.sendMessage(chatId, {
          message: `🔒 **FITUR PREMIUM**
────────────────────

❌ **Akses ditolak!**

Menu utilitas Flutter hanya dapat digunakan oleh **MEMBER PREMIUM**.

────────────────────

💡 __Upgrade ke Premium untuk menikmati semua fitur eksklusif.__`,
          parseMode: "md"
        });
        return;
      }

      await client.sendMessage(chatId, {
        message: `🛠️ **FLUTTER PREMIUM ENGINE**
────────────────────

Selamat datang di pusat utilitas manipulasi source code Flutter Cloud.

Silakan pilih fitur yang ingin Anda jalankan bray:

├ 🌐 **RENAME DOMAIN**
│  ├ 🔗 Mengubah endpoint API / URL lama
│  └ 🔍 Mencari string domain di file .dart
│
├ 📝 **CUSTOM TEXT RENAME**
│  ├ 🏷️ Mengubah nama aplikasi, nama kelas, 
│  │   atau teks tertentu secara massal
│  └ 🔍 Mengganti teks apa pun di file .dart
│
├ 🔍 **FLUTTER ANALYZE ERROR**
│  ├ 🚨 Memindai sintaks eror & warning kodingan
│  └ 📝 Menampilkan baris yang rusak secara detail
│
└ 🖼️ **UBAH FOTO**
   ├ 📸 Mengganti semua file gambar (.png, .jpg)
   └ 🔄 Dengan foto baru dari Anda

────────────────────

⏱️ __VM Server Ready to Processing__`,
        parseMode: "md",
        buttons: buildButtons([
          [
            { text: "🌐 Rename Domain", data: "start_rename_domain" },
            { text: "📝 Custom Rename", data: "start_rename_custom" }
          ],
          [
            { text: "🔍 Flutter Analyze Error", data: "start_flutter_analyze" }
          ],
          [
            { text: "🖼️ Ubah Foto", data: "start_rename_photo" }
          ],
          [{ text: "🏠 Kembali ke Menu", data: "start" }]
        ])
      });
      return;
    }

    if (data === "start_rename_domain" || data === "start_rename_custom" || data === "start_flutter_analyze" || data === "start_rename_photo") {
      try {
        await client.deleteMessages(chatId, [msgId], { revoke: true });
      } catch (_) {}

      if (data === "start_flutter_analyze") {
        renameState[userId] = { step: 0, type: "analyze" };
        await client.sendMessage(chatId, {
          message: `🔥 **🔍 FLUTTER ANALYZE ERROR**
────────────────────

Silakan **kirim/upload file .zip** project Flutter Anda ke sini bray.

Sistem akan mengekstrak file dan melakukan pengecekan sintaks secara menyeluruh menggunakan kompiler internal server.

📦 **PERSYARATAN**
├ 📂 Format : \`.zip\`
└ 📁 Wajib ada : File \`pubspec.yaml\` di dalam ZIP

────────────────────

💡 __Kirim file ZIP yang mau di-scan erornya bray.__`,
          parseMode: "md"
        });
        return;
      }

      if (data === "start_rename_photo") {
        renameState[userId] = { step: 0, type: "photo" };
        await client.sendMessage(chatId, {
          message: `🖼️ **UBAH FOTO/ICON PROJECT**
────────────────────

Silakan **kirim/upload file .zip** project Flutter Anda ke sini.

📦 **PERSYARATAN**
├ 📂 Format : \`.zip\`
├ 📁 Wajib ada : Folder project Flutter
└ 🖼️ Akan mengganti semua file gambar (.png, .jpg) di dalam project dengan foto baru.

────────────────────

💡 __Pastikan file ZIP berisi project Flutter yang lengkap.__`,
          parseMode: "md",
          buttons: buildButtons([[{ text: "❌ Batalkan", data: "cancel_rename" }]])
        });
        return;
      }

      const type = data === "start_rename_domain" ? "domain" : "custom";
      renameState[userId] = { step: 0, type: type };

      const modeTitle = type === "domain" ? "🌐 RENAME DOMAIN" : "📝 CUSTOM TEXT RENAME";

      await client.sendMessage(chatId, {
        message: `🔥 **${modeTitle}**
────────────────────

Silakan **kirim/upload file .zip** project Flutter Anda ke sini.

📦 **PERSYARATAN**
├ 📂 Format : \`.zip\`
├ 📁 Wajib ada : Folder project Flutter
└ 🔍 Akan memindai semua file \`.dart\`

────────────────────

💡 __Pastikan file ZIP berisi project yang lengkap bray.__`,
        parseMode: "md"
      });
      return;
    }

    if (data === "menu_rename") {
      try {
        await client.deleteMessages(chatId, [msgId], { revoke: true });
      } catch (_) {}

      const isPremium = isPremiumUser(userId);
      const isOwner = userId === OWNER_ID;
  
      if (!isPremium && !isOwner) {
        await client.sendMessage(chatId, {
          message: `🔒 **FITUR PREMIUM**
────────────────────

❌ **Akses ditolak!**

Fitur **Rename Domain** hanya dapat digunakan oleh **MEMBER PREMIUM**.

────────────────────

💡 __Upgrade ke Premium untuk menikmati semua fitur eksklusif.__`,
          parseMode: "md"
        });
        return;
      }
   
      renameState[userId] = { step: 0 };
      await client.sendMessage(chatId, {
        message: `🔥 **RENAME FLUTTER PROJECT**
────────────────────

📋 **INSTRUKSI**

Silakan **kirim/upload file .zip** project Flutter Anda ke sini.

📦 **PERSYARATAN**
├ 📂 Format : \`.zip\`
├ 📁 Wajib ada : Folder project Flutter
└ 🔍 Akan mencari & mengganti domain di semua file \`.dart\`

────────────────────

💡 __Pastikan file ZIP berisi project Flutter yang lengkap.__`,
        parseMode: "md"
      });
      return;
    }

    if (data === "exec_analyze_code") {
      const state = renameState[userId];
      if (!state || !state.mediaMessage) {
        await client.sendMessage(chatId, {
          message: `❌ **SESSION EXPIRED**
────────────────────

⚠️ Session Anda telah kedaluwarsa bray.

💡 __Silakan klik ulang menu **Menu Flutter** untuk memulai kembali.__`,
          parseMode: "md"
        });
        return;
      }

      const statusMsg = await client.sendMessage(chatId, { 
        message: `⏳ **PREPARING GITHUB ANALYZE**
────────────────────

🔥 Mendownload file ZIP...
📦 Mengupload berkas ke GitHub Release...
🚀 Memicu pemindaian via GitHub Actions...

⏱ __Mohon tunggu bray, proses remote scanning sedang diinisialisasi...__`,
        parseMode: "md"
      });

      const { mediaMessage } = state;
      const downloadPath = path.join(TMP_DIR, `anz_${userId}_${Date.now()}.zip`);
      const tagName = `anz-${userId}-${Date.now()}`;

      try {
        if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

        const buffer = await client.downloadMedia(mediaMessage, {});
        fs.writeFileSync(downloadPath, buffer);

        const release = await github.createReleaseOnly(tagName);
        const upload = await github.uploadAssetFile(release.uploadUrl, downloadPath, "project.zip", "application/zip");

        await client.sendMessage(chatId, {
          message: `🚀 **ANALYSIS TRIGGERED**
────────────────────

✅ Berkas berhasil dideploy ke GitHub!
⏱ Sistem sedang menjalankan \`flutter analyze\` di server GitHub.

__Laporan hasil pengecekan kode akan dikirim ke sini setelah selesai...__`,
          parseMode: "md"
        });

        const beforeTrigger = new Date().toISOString();
        await github.githubRequest(
          "POST",
          `/repos/${GITHUB_OWNER}/${GITHUB_REPO}/actions/workflows/build.yml/dispatches`,
          {
            ref: "main",
            inputs: {
              zip_url: upload.url,
              tag: tagName,
              build_type: "release",
              only_analyze: "true"
            },
          }
        );

        const runId = await github.waitForNewRunId(beforeTrigger, 45000);
        
        let checked = false;
        while (!checked) {
          await github.sleep(5000);
          const runStatus = await github.getRunStatus(runId);
          
          if (runStatus.status === "completed") {
            checked = true;
            
            if (runStatus.conclusion === "success") {
              await client.sendMessage(chatId, {
                message: `✅ **ANALYZE CODE PASSED**
────────────────────

🎉 **Selamat bray! Tidak ada eror sintaks ditemukan.**

\`\`\`
No issues found! Kode Anda bersih dan siap di-build menjadi APK.
\`\`\``,
                parseMode: "md",
                buttons: buildButtons([[{ text: "🏠 Menu Premium", data: "menu_flutter_premium" }]])
              });
            } else {
              await github.sleep(4000);

              const jobsRes = await github.githubRequest(
                "GET",
                `/repos/${GITHUB_OWNER}/${GITHUB_REPO}/actions/runs/${runId}/jobs`
              );
              const jobs = jobsRes.body?.jobs || [];
              const failedJob = jobs.find((j) => j.conclusion === "failure");
              
              let cleanOutput = "";
              if (failedJob) {
                const logRes = await github.githubRequest(
                  "GET",
                  `/repos/${GITHUB_OWNER}/${GITHUB_REPO}/actions/jobs/${failedJob.id}/logs`
                );
                
                if (typeof logRes.body === "string") {
                  const allLines = logRes.body
                    .split("\n")
                    .map(line => {
                      let clean = line.replace(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d+Z\s*/, "");
                      clean = clean.replace(/^##\[[a-zA-Z]+\]\s*/, "");
                      clean = clean.replace(/\x1B\[[0-9;]*[a-zA-Z]/g, "");
                      clean = clean.replace(/</g, "&lt;").replace(/>/g, "&gt;");
                      return clean.trim();
                    });

                  const filteredLines = allLines.filter(line => {
                    if (!line) return false;
                    const lower = line.toLowerCase();
                    if (lower.includes("install") || lower.includes("sdk") || lower.includes("platform") || lower.includes("revision")) return false;
                    if (lower.includes("force_javascript") || lower.includes("shell:") || lower.includes("bash") || lower.includes("gradle task")) return false;
                    if (lower.includes("cleanup") || lower.includes("orphan") || lower.includes("terminate") || lower.includes("hostedtoolcache")) return false;
                    if (lower.includes("help.gradle.org") || lower.includes("stacktrace") || lower.includes("info or --debug") || lower.includes("--scan")) return false;
                    return true;
                  });

                  cleanOutput = filteredLines.slice(-15).join("\n");
                }
              }

              if (!cleanOutput || cleanOutput.trim().length === 0) {
                cleanOutput = "Tidak berhasil menangkap cuplikan teks kode yang rusak.\nSilakan periksa secara manual kodingan Flutter Anda.";
              }

              if (cleanOutput.length > 1500) {
                cleanOutput = cleanOutput.substring(0, 1500) + "\n... (Sisa laporan terpotong bray)";
              }

              const finalMessage = `🚨 <b>ANALYZE CODE REPORT</b>
────────────────────

⚠️ <b>Ditemukan masalah pada kodingan Dart Anda:</b>

<pre>${cleanOutput}</pre>

💡 <i>Perbaiki baris kode di atas sebelum melakukan build APK bray.</i>`;

              await client.sendMessage(chatId, {
                message: finalMessage,
                parseMode: "html",
                buttons: buildButtons([[{ text: "🏠 Menu Premium", data: "menu_flutter_premium" }]])
              });
            }
          }
        }

        delete renameState[userId];
        await github.deleteRelease(release.releaseId);
        if (fs.existsSync(downloadPath)) fs.unlinkSync(downloadPath);
        try { await client.deleteMessages(chatId, [statusMsg.id], { revoke: true }); } catch (_) {}

      } catch (err) {
        await client.sendMessage(chatId, { 
          message: `❌ **ANALYZE FAILED**
────────────────────

🛑 **Gagal menjalankan pemindaian:**
\`${err.message}\``,
          parseMode: "md"
        });
        delete renameState[userId];
        if (fs.existsSync(downloadPath)) fs.unlinkSync(downloadPath);
        try { await client.deleteMessages(chatId, [statusMsg.id], { revoke: true }); } catch (_) {}
      }
      return;
    }

    if (data === "exec_rename") {
      const state = renameState[userId];
      if (!state || !state.mediaMessage || !state.oldDomain || !state.newDomain) {
        await client.sendMessage(chatId, {
          message: `❌ **SESSION EXPIRED**
────────────────────

⚠️ Session Anda telah kedaluwarsa.

💡 __Silakan klik ulang menu **Rename** untuk memulai kembali.__`,
          parseMode: "md"
        });
        return;
      }

      const statusMsg = await client.sendMessage(chatId, { 
        message: `⏳ **PROCESSING RENAME**
────────────────────

🔥 Mendownload file ZIP...
🔍 Memindai file \`.dart\`...
🔄 Mengganti nama teks...

⏱ __Harap tunggu, proses ini membutuhkan waktu beberapa saat.__`,
        parseMode: "md"
      });

      const { mediaMessage, oldDomain, newDomain, type } = state;

      const workDir = path.join(TMP_DIR, `rename_${userId}_${Date.now()}`);
      const downloadPath = path.join(TMP_DIR, `download_${userId}_${Date.now()}.zip`);
      const newZipPath = path.join(TMP_DIR, `output_${userId}_${Date.now()}.zip`);

      try {
        if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

        const buffer = await client.downloadMedia(mediaMessage, {});
        fs.writeFileSync(downloadPath, buffer);

        const AdmZip = require('adm-zip');
        const zip = new AdmZip(downloadPath);
        if (!fs.existsSync(workDir)) fs.mkdirSync(workDir, { recursive: true });
        zip.extractAllTo(workDir, true);

        let renamedFiles = [];
        
        function scanAndReplace(dir) {
          const files = fs.readdirSync(dir);
          for (const file of files) {
            const fullPath = path.join(dir, file);
            if (fs.statSync(fullPath).isDirectory()) {
              scanAndReplace(fullPath);
            } else if (file.endsWith('.dart')) {
              let content = fs.readFileSync(fullPath, 'utf8');
              if (content.includes(oldDomain)) {
                const updatedContent = content.split(oldDomain).join(newDomain);
                fs.writeFileSync(fullPath, updatedContent, 'utf8');
                renamedFiles.push(path.relative(workDir, fullPath));
              }
            }
          }
        }
        
        scanAndReplace(workDir);

        if (renamedFiles.length === 0) {
          await client.sendMessage(chatId, { 
            message: `⚠️ **NO MATCH FOUND**
────────────────────

❌ Tidak menemukan kata **\`${oldDomain}\`** di file \`.dart\` manapun.

📋 **SARAN**
├ 1️⃣ Periksa ejaan teks lama Anda
├ 2️⃣ Pastikan file \`.dart\` ada
└ 3️⃣ Coba cari manual di kodingan

────────────────────

💡 __Gunakan kata yang tepat sesuai dengan yang ada di source code Anda.__`,
            parseMode: "md"
          });
          delete renameState[userId];
          fs.rmSync(workDir, { recursive: true, force: true });
          if (fs.existsSync(downloadPath)) fs.unlinkSync(downloadPath);
          try { await client.deleteMessages(chatId, [statusMsg.id], { revoke: true }); } catch (_) {}
          return;
        }

        const outputZip = new AdmZip();
        outputZip.addLocalFolder(workDir);
        outputZip.writeZip(newZipPath);

        let fileListText = renamedFiles.map(f => `├ 📄 \`${f}\``).join('\n');
        if (fileListText.length > 800) {
          fileListText = fileListText.substring(0, 800) + '\n└ __... dan file lainnya__';
        } else {
          fileListText = `┌────────────────────\n${fileListText}\n└────────────────────`;
        }
        
        await client.sendFile(userId, {
          file: newZipPath,
          fileName: `renamed_${type || 'custom'}_${Date.now()}.zip`,
          caption: `✅ **RENAME SUCCESSFUL**
────────────────────

🔄 **RENAME DETAILS**
├ 🛠️ Mode : \`${(type || 'custom').toUpperCase()}\`
├ ❌ Old Text : \`${oldDomain}\`
└ ✅ New Text : \`${newDomain}\`

📊 **SUMMARY**
├ 📁 Files scanned : __Semua file .dart__
├ 🔄 Files changed : \`${renamedFiles.length}\` file(s)
└ 📦 Output size : \`${(fs.statSync(newZipPath).size / 1024 / 1024).toFixed(2)} MB\`

────────────────────

📂 **FILES MODIFIED**
${fileListText}

────────────────────

🎉 __Project Anda telah berhasil direname! File ZIP baru dikirim langsung ke DM Anda.__`,
          parseMode: "md"
        });

        if (chatId !== userId) {
          await client.sendMessage(chatId, {
            message: `✅ **Proses Selesai bray!** Hasil file ZIP yang sudah direname telah dikirim langsung ke private chat (DM) user \`${userId}\`.`,
            parseMode: "md"
          });
        }

        delete renameState[userId];
        fs.rmSync(workDir, { recursive: true, force: true });
        if (fs.existsSync(downloadPath)) fs.unlinkSync(downloadPath);
        if (fs.existsSync(newZipPath)) fs.unlinkSync(newZipPath);
        try { await client.deleteMessages(chatId, [statusMsg.id], { revoke: true }); } catch (_) {}

      } catch (err) {
        console.error(err);
        await client.sendMessage(chatId, { 
          message: `❌ **RENAME FAILED**
────────────────────

🛑 **ERROR DETAILS**
├ 📝 Message : \`${err.message}\`
└ 🔧 Action : __Rename process interrupted__

────────────────────

⚠️ **TROUBLESHOOTING**
├ 1️⃣ Pastikan file ZIP tidak corrupt
├ 2️⃣ Periksa struktur folder project
└ 3️⃣ Coba lagi dengan file yang berbeda

────────────────────

💡 __Jika error terus muncul, hubungi admin.__`,
          parseMode: "md"
        });
        
        delete renameState[userId];
        if (fs.existsSync(workDir)) fs.rmSync(workDir, { recursive: true, force: true });
        if (fs.existsSync(downloadPath)) fs.unlinkSync(downloadPath);
        if (fs.existsSync(newZipPath)) fs.unlinkSync(newZipPath);
        try { await client.deleteMessages(chatId, [statusMsg.id], { revoke: true }); } catch (_) {}
      }
      return;
    }

    if (data === "cancel_rename") {
      delete renameState[userId];
      try {
        await client.deleteMessages(chatId, [msgId], { revoke: true });
      } catch (_) {}
      await client.sendMessage(chatId, { 
        message: `❌ **RENAME CANCELLED**
────────────────────

⚠️ Proses modifikasi project Flutter Anda telah dibatalkan bray.

💡 __Silakan buka kembali Menu Flutter jika ingin memproses ulang.__`,
        parseMode: "md",
        buttons: buildButtons([[{ text: "🏠 Menu Utama", data: "start" }]])
      });
      return;
    }

    if (data === "user_start_lapor") {
      if (db.isReportBlocked(userId)) {
        return event.answer({
          message: "❌ Akses Ditolak! Kamu telah diblokir dari fitur laporan karena terindikasi mengirimkan laporan palsu.",
          alert: true
        });
      }

      userStates.set(userId, { step: 'WAITING_FOR_REASON' });
      await client.editMessage(chatId, {
        message: msgId,
        text: `📝 **MENU LAPORAN**

Silakan ketik **Alasan & Detail Laporan** kamu dengan jelas, lalu kirimkan lewat chat di bawah ini.

⚠️ __Laporan asal-asalan/palsu akan mengakibatkan akun kamu diblokir dari fitur bot.__`,
        parseMode: "md",
        buttons: buildButtons([[{ text: "❌ Batalkan Laporan", data: "cancel" }]])
      });
      return await event.answer();
    }

    const isAdminAction = data.startsWith("adm_fix_") || data.startsWith("adm_blk_") || data.startsWith("adm_unblk_");
    if (isAdminAction) {
      if (chatId !== CONFIG.ADMIN_GROUP_ID && !isAdmin(userId)) {
        return await event.answer({ message: "❌ Kamu tidak memiliki akses admin!", alert: true });
      }

      let originalMsgText = "Laporan User";
      try {
        const fullMsg = await client.getMessages(chatId, { ids: [msgId] });
        originalMsgText = fullMsg[0]?.message || fullMsg[0]?.caption || "Laporan User";
      } catch (err) {
        console.error("Gagal get original message:", err);
      }

      if (data.startsWith("adm_fix_")) {
        const targetUserId = Number(data.replace("adm_fix_", ""));
        try {
          await client.sendMessage(targetUserId, {
            message: `🎉 **LAPORAN SELESAI DIPROSES**

Halo, kendala/bug yang kamu laporkan sebelumnya **telah berhasil diperbaiki** oleh tim admin.

Terima kasih banyak atas kontribusi dan laporan kamu! Silakan dicoba kembali fiturnya.`,
            parseMode: "md"
          });
          await event.answer({ message: "✅ Berhasil memberi tahu user!", alert: false });
        } catch (err) {
          await event.answer({ message: "⚠️ Gagal kirim DM (User memblokir bot)", alert: true });
        }

        await client.editMessage(chatId, {
          message: msgId,
          text: originalMsgText + `\n\n` + `🟢 **STATUS:** Selesai diperbaiki & user telah diberitahu.`,
          parseMode: "md",
          buttons: buildButtons([[{ text: "🔒 Blokir User", data: `adm_blk_${targetUserId}` }]])
        });
        return;
      }

      if (data.startsWith("adm_blk_")) {
        const targetUserId = Number(data.replace("adm_blk_", ""));
        if (db.isReportBlocked(targetUserId)) {
          return await event.answer({ message: "ℹ️ User ini sudah berstatus diblokir.", alert: true });
        }
        db.blockReportUser(targetUserId);
        await event.answer({ message: `🔒 ID ${targetUserId} Berhasil Diblokir`, alert: false });

        const cleanedMessage = originalMsgText.replace(`\n\n🟢 **STATUS:** Selesai diperbaiki & user telah diberitahu.`, "");
        await client.editMessage(chatId, {
          message: msgId,
          text: cleanedMessage + `\n\n` + `🔴 **STATUS:** User telah diblokir oleh admin karena laporan palsu.`,
          parseMode: "md",
          buttons: buildButtons([[{ text: "🔓 Unblokir User", data: `adm_unblk_${targetUserId}` }]])
        });

        try {
          await client.sendMessage(targetUserId, {
            message: `⚠️ **AKSES DIBLOKIR**

Fitur laporan kamu telah dinonaktifkan oleh tim admin karena terindikasi mengirimkan laporan palsu/spam.`,
            parseMode: "md"
          });
        } catch (err) {}
        return;
      }

      if (data.startsWith("adm_unblk_")) {
        const targetUserId = Number(data.replace("adm_unblk_", ""));
        if (!db.isReportBlocked(targetUserId)) {
          return await event.answer({ message: "ℹ️ User tidak sedang dalam pemblokiran.", alert: true });
        }
        db.unblockReportUser(targetUserId);
        await event.answer({ message: `🔓 Blokir ID ${targetUserId} Telah Dibuka`, alert: false });

        const cleanedMessage = originalMsgText.replace(`\n\n🔴 **STATUS:** User telah diblokir oleh admin karena laporan palsu.`, "");
        await client.editMessage(chatId, {
          message: msgId,
          text: cleanedMessage + `\n\n` + `⚪ **STATUS:** Akses laporan dikembangkan normal.`,
          parseMode: "md",
          buttons: buildButtons([
            [{ text: "✅ Masalah Selesai", data: `adm_fix_${targetUserId}` }],
            [
              { text: "🔒 Blokir", data: `adm_blk_${targetUserId}` },
              { text: "🔓 Unblokir", data: `adm_unblk_${targetUserId}` }
            ]
          ])
        });

        try {
          await client.sendMessage(targetUserId, {
            message: `✅ **AKSES DIKEMBALIKAN**

Fitur laporan kamu telah diaktifkan kembali. Mohon gunakan fasilitas ini dengan bijak.`,
            parseMode: "md"
          });
        } catch (err) {}
        return;
      }
    }

    if (data === "check_join") {
      const joined = await isJoinedChannel(userId);

      if (!joined) {
        return event.answer({
          message: "❌ Kamu belum join semua channel!",
          alert: true,
        });
      }

      await event.answer({ message: "✅ Verifikasi berhasil!" });

      let firstName = "User";
      try {
        const entity = await client.getEntity(userId);
        firstName = entity?.firstName || "User";
      } catch (_) {}

      return handleStart(
        {
          chatId,
          message: {
            getSender: async () => ({
              id: userId,
              firstName,
              username: null,
            }),
          },
        },
        msgId
      );
    }

    await event.answer();

    if (data === "start") {
      return await handleStart(
        {
          chatId,
          message: {
            getSender: async () => {
              try {
                const entity = await client.getEntity(userId);
                return {
                  id: userId,
                  firstName: entity?.firstName || "User",
                  username: entity?.username || null,
                };
              } catch (_) {
                return { id: userId, firstName: "User" };
              }
            },
          },
        },
        msgId
      );
    }

    if (data === "build") return await handleBuild(chatId, userId, null, msgId);
    if (data === "build_debug") return await handleBuild(chatId, userId, "debug", msgId);
    if (data === "build_release") return await handleBuild(chatId, userId, "release", msgId);
    if (data === "web2apk") return await handleWeb2Apk(chatId, userId, msgId);
    if (data === "queue") return await handleQueue(chatId, msgId);
    if (data === "help") return await handleHelp(chatId, msgId);
    if (data === "status") return await handleStatus(chatId, userId, msgId);

    if (data === "owner_setup_github") {
      if (userId !== OWNER_ID) return;
      
      await send(chatId, `⏳ **Memulai Auto-Setup GitHub...**\n\n__Harap tunggu, proses ini mungkin butuh beberapa saat bray.__`, null, msgId);
      
      try {
        console.log("🔧 [OWNER] Memulai Auto-Setup GitHub...");
        
        const result = await github.runAutoSetupGitHub();
        
        console.log("✅ [OWNER] Auto-Setup GitHub selesai:", result);
        
        return send(
          chatId, 
          `✅ **Setup berhasil!**

📊 **HASIL SETUP**
├ 🔑 Token: ${result?.token ? '✅ OK' : '❌ GAGAL'}
├ 📁 Repo: ${result?.repo ? '✅ OK' : '❌ GAGAL'}
├ 🔐 Secrets: ${result?.secrets ? '✅ OK' : '❌ GAGAL'}
└ 📄 Workflow: ${result?.workflow ? '✅ OK' : '❌ GAGAL'}

__Seluruh ekosistem GitHub udah di-setup otomatis bray! Bot siap gas.__`,
          [[{ text: "🏠 Menu Utama", data: "start" }]]
        );
        
      } catch (err) {
        console.error("❌ [OWNER] Auto-Setup GitHub GAGAL:", err);
        console.error("📝 Stack trace:", err.stack);
        
        return send(
          chatId,
          `❌ **Setup GAGAL!**

📋 **DETAIL ERROR**
├ 📝 Message: \`${err.message || 'Unknown error'}\`
├ 📂 File: \`${err.file || 'N/A'}\`
└ 📊 Line: \`${err.line || 'N/A'}\`

⚠️ **TROUBLESHOOTING**
├ 1️⃣ Cek GitHub Token di config
├ 2️⃣ Pastikan repo ada & bisa diakses
└ 3️⃣ Cek log console untuk detail lengkap

💡 __Coba lagi atau hubungi admin.__`,
          [[{ text: "🏠 Menu Utama", data: "start" }]]
        );
      }
    }

    if (data === "cancel") {
      removeUserJob(userId);
      userStates.delete(userId);
      return await send(
        chatId,
        `✅ **Dibatalkan.**

__Ketik /start atau klik tombol di bawah untuk kembali ke menu utama.__`,
        [[{ text: "🏠 Menu Utama", data: "start" }]],
        msgId
      );
    }
  } catch (err) {
    console.error("handleCallback error:", err);
  }
}

// ─── MAIN ──────────────────────────────────────────────────────────
async function main() {
  console.log(`🚀 Starting ${CONFIG.BOT_NAME}...`);

  if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });
  
  await client.start({
    botAuthToken: BOT_TOKEN,
    onError: (err) => console.error("Client error:", err),
  });

  fs.writeFileSync(SESSION_FILE, client.session.save());
  console.log("✅ Bot connected & session saved!");

  client.addEventHandler(async (event) => {
    try {
      const msg = event.message;
      const text = msg?.text?.trim();
      const chatId = event.chatId;
      const userId = Number(msg.senderId);
      
      // ─── HANDLE RENAME STATE ────────────────────────────────────
      if (renameState[userId]) {
        const state = renameState[userId];
        const isMedia = msg.media && msg.media.document;
        const isPhoto = msg.media && msg.media.photo;

        // --- FITUR UBAH FOTO ---
        if (state.type === "photo" && state.step === 0 && isMedia) {
          state.mediaMessage = msg;
          state.step = 1;
          await client.sendMessage(chatId, {
            message: `✅ **ZIP DITERIMA!**
────────────────────

📦 **File ZIP berhasil diterima!**

Sekarang, **kirimkan foto baru** yang ingin digunakan sebagai pengganti semua gambar di project.

🖼️ **KETERANGAN**
├ 📸 Format : Foto/Image (PNG, JPG)
├ 📏 Ukuran : Akan di-resize sesuai kebutuhan
└ 🔧 Tindakan : Semua file gambar (.png, .jpg) di project akan diganti dengan foto ini.

────────────────────

💡 __Kirim foto dengan kualitas terbaik untuk hasil maksimal.__`,
            parseMode: "md",
            buttons: buildButtons([[{ text: "❌ Batalkan", data: "cancel_rename" }]])
          });
          return;
        }

        if (state.type === "photo" && state.step === 1 && (isPhoto || (isMedia && msg.media.document.mimeType && msg.media.document.mimeType.startsWith("image/")))) {
          await handleReplacePhoto(event, userId, chatId, state);
          return;
        }

        // --- ANALYZE ---
        if (state.type === "analyze" && state.step === 0 && isMedia) {
          state.mediaMessage = msg;
          state.step = 3;
          await client.sendMessage(chatId, {
            message: `📋 **ANALYZE CONFIRMATION**
────────────────────

📊 **ANALYZE DETAILS**
├ 🛠️ Mode : \`FLUTTER ANALYZE ERROR\`
└ 📦 File : \`${msg.media.document.attributes?.find(a => a.fileName)?.fileName || 'ZIP File'}\`

────────────────────

💡 __Sistem akan menguji dependensi pub get dan mendeteksi kerusakan kode Dart Anda.__

────────────────────

✅ **Sudah benar bray? Klik tombol di bawah untuk mulai pemindaian.**`,
            parseMode: "md",
            buttons: buildButtons([
              [
                { text: "🔍 Mulai Scan Sekarang", data: "exec_analyze_code" },
                { text: "❌ Batalkan", data: "cancel_rename" }
              ]
            ])
          });
          return;
        }

        // --- RENAME DOMAIN / CUSTOM ---
        if (state.type !== "photo" && state.type !== "analyze") {
          if (state.step === 0 && isMedia) {
            state.mediaMessage = msg;
            state.step = 1;
            const labelLama = state.type === "domain" ? "Masukkan Domain Lama" : "Masukkan Teks/Nama Lama";
            const contohLama = state.type === "domain" ? "Contoh: \`https://api.old.com\` atau \`old.com\`" : "Contoh: \`NamaAppLama\` atau \`old_variable\`";

            await client.sendMessage(chatId, {
              message: `✅ **FILE RECEIVED**
────────────────────

📦 **File ZIP berhasil diterima!**

📊 **FILE INFO**
├ 📂 Nama : \`${msg.media.document.attributes?.find(a => a.fileName)?.fileName || 'project.zip'}\`
└ 📏 Ukuran : \`${(msg.media.document.size / 1024 / 1024).toFixed(2)} MB\`

────────────────────

📝 **${labelLama}**

Ketik kata/teks asli yang ingin Anda ganti di semua file \`.dart\`.

💡 __${contohLama}__`,
              parseMode: "md"
            });
            return;
          }

          if (state.step === 1 && text) {
            state.oldDomain = text;
            state.step = 2;

            const labelBaru = state.type === "domain" ? "Masukkan Domain Baru" : "Masukkan Teks/Nama Baru";
            const contohBaru = state.type === "domain" ? "Contoh: \`https://api.new.com\` atau \`new.com\`" : "Contoh: \`NamaAppBaru\` atau \`new_variable\`";

            await client.sendMessage(chatId, {
              message: `📝 **TEKS LAMA TERSIMPAN**
────────────────────

✅ **Target Teks:** \`${state.oldDomain}\`

────────────────────

✏️ **${labelBaru}**

Ketik kata/teks pengganti baru yang akan digunakan.

💡 __${contohBaru}__`,
              parseMode: "md"
            });
            return;
          }

          if (state.step === 2 && text) {
            state.newDomain = text;
            state.step = 3;

            await client.sendMessage(chatId, {
              message: `📋 **RENAME CONFIRMATION**
────────────────────

📊 **RENAME DETAILS**
├ 🛠️ Mode : \`${state.type.toUpperCase()}\`
├ 📦 File : \`${state.mediaMessage?.media?.document?.attributes?.find(a => a.fileName)?.fileName || 'ZIP File'}\`
├ ❌ Teks Lama : \`${state.oldDomain}\`
└ ✅ Teks Baru : \`${state.newDomain}\`

────────────────────

⚠️ **PERINGATAN**
__Proses ini akan mengganti SEMUA kemunculan kata lama ke kata baru di seluruh file \`.dart\` project Anda.__

────────────────────

✅ **Sudah benar bray? Klik tombol di bawah untuk mengeksekusi.**`,
              parseMode: "md",
              buttons: buildButtons([
                [
                  { text: "🚀 Gas Proses Sekarang", data: "exec_rename" },
                  { text: "❌ Batalkan", data: "cancel_rename" }
                ]
              ])
            });
            return;
          }
        }

        await client.sendMessage(chatId, {
          message: `⚠️ **Ikuti alur rename:**
1. Kirim file ZIP project Flutter
2. Kirim teks lama yang mau diganti
3. Kirim teks baru pengganti

Silakan kirim sesuai urutan langkah di atas bray.`,
          parseMode: "md"
        });
        return;
      }

      if (text === "/start") return handleStart(event);
      if (text === "/help") return handleHelp(chatId);

      if (text?.startsWith("/broadcast") && isAdmin(userId)) {
        const replied = await event.message.getReplyMessage();
        if (!replied) return send(chatId, `⚠️ Reply pesan yang ingin di-broadcast!`);

        await send(chatId, `🚀 **Broadcast dimulai...**`);

        const users = db.getAllUsers();
        let success = 0, failed = 0;

        for (const user of users) {
          try {
            if (replied.media) {
              await client.forwardMessages(user.userId, {
                messages: [replied.id],
                fromPeer: replied.chatId,
              });
            } else {
              await send(user.userId, replied.text || replied.caption || "");
            }
            success++;
            await sleep(500);
          } catch (_) {
            failed++;
          }
        }

        return send(
          chatId,
          `✅ **Broadcast Selesai!**

✅ **Sukses :** ${success}
❌ **Gagal  :** ${failed}`
        );
      }

      if (text?.startsWith("/forward") && isAdmin(userId)) {
        const replied = await event.message.getReplyMessage();
        if (!replied) return send(chatId, `⚠️ Reply pesan yang ingin di-forward!`);

        await send(chatId, `🚀 **Forward dimulai...**`);

        const users = db.getAllUsers();
        let success = 0, failed = 0;

        for (const user of users) {
          try {
            await client.forwardMessages(user.userId, {
              messages: [replied.id],
              fromPeer: replied.chatId,
            });
            success++;
            await sleep(300);
          } catch (_) {
            failed++;
          }
        }

        return send(
          chatId,
          `✅ **Forward Selesai!**

✅ **Sukses :** ${success}
❌ **Gagal  :** ${failed}`
        );
      }

      if (text?.startsWith("/adduser") && isAdmin(userId)) {
        const args = text.split(/\s+/).slice(1);
        const [rawId, role] = args;

        if (!rawId || !/^\d+$/.test(rawId)) {
          return send(
            chatId,
            `⚠️ **Format salah bray!**

Gunakan: \`/adduser <id_telegram> <role>\`
Contoh: \`/adduser 7926135540 admin\`

__Role bisa \`admin\` atau \`member\`. Kalau tidak diisi, default-nya \`member\`.__
__ID Telegram bisa dilihat lewat bot seperti @userinfobot.__`
          );
        }

        const targetId = rawId;
        const userRole = (role || "member").toLowerCase();

        const dataDir = path.join(__dirname, "data");
        if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

        const userDbPath = path.join(dataDir, "user.json");
        let panelUsers = [];
        if (fs.existsSync(userDbPath)) {
          try {
            panelUsers = JSON.parse(fs.readFileSync(userDbPath, "utf-8"));
          } catch (_) {
            panelUsers = [];
          }
        }

        let newUsername;
        do {
          newUsername = "user" + Math.floor(100000 + Math.random() * 900000);
        } while (panelUsers.find((u) => u.username === newUsername));

        const newPassword = generateRandomPassword(10);

        panelUsers.push({
          username: newUsername,
          password: newPassword,
          role: userRole,
          telegramId: targetId,
        });
        fs.writeFileSync(userDbPath, JSON.stringify(panelUsers, null, 2));

        const credText =
          `🔐 **Akun Panel Build Kamu Sudah Dibuat!**

👤 **Username** ➜ \`${newUsername}\`
🔑 **Password** ➜ \`${newPassword}\`
🏷️ **Role** ➜ \`${userRole}\`

__Simpan baik-baik dan jangan share ke siapapun bray!__`;

        let dmSent = true;
        try {
          await client.sendMessage(Number(targetId), { message: credText, parseMode: "md" });
        } catch (_) {
          dmSent = false;
        }

        return send(
          chatId,
          `✅ **Akun panel berhasil dibuat untuk ID \`${targetId}\`!**

👤 **Username** ➜ \`${newUsername}\`
🔑 **Password** ➜ \`${newPassword}\`
🏷️ **Role** ➜ \`${userRole}\`

${dmSent
  ? `📩 __Detail login juga sudah dikirim ke DM user tersebut.__`
  : `⚠️ __Gagal kirim DM ke user (kemungkinan user belum pernah /start bot ini). Tolong kirim manual data di atas ke user.__`}`
        );
      }

      if (text?.startsWith("/deluser") && isAdmin(userId)) {
        const rawUsername = text.split(/\s+/)[1];
        if (!rawUsername) {
          return send(chatId, `⚠️ Gunakan: \`/deluser <username>\``);
        }

        const username = rawUsername.trim().toLowerCase();
        const userDbPath = path.join(__dirname, "data", "user.json");

        if (!fs.existsSync(userDbPath)) {
          return send(chatId, `⚠️ Database user panel masih kosong bray.`);
        }

        let panelUsers = JSON.parse(fs.readFileSync(userDbPath, "utf-8"));
        const before = panelUsers.length;
        panelUsers = panelUsers.filter((u) => u.username !== username);

        if (panelUsers.length === before) {
          return send(chatId, `⚠️ Username \`${username}\` tidak ditemukan bray.`);
        }

        fs.writeFileSync(userDbPath, JSON.stringify(panelUsers, null, 2));
        return send(chatId, `✅ Akun panel \`${username}\` berhasil dihapus.`);
      }

      if (text === "/listuser" && isAdmin(userId)) {
        const userDbPath = path.join(__dirname, "data", "user.json");

        if (!fs.existsSync(userDbPath)) {
          return send(chatId, `📂 Database user panel masih kosong bray.`);
        }

        const panelUsers = JSON.parse(fs.readFileSync(userDbPath, "utf-8"));
        if (!panelUsers.length) {
          return send(chatId, `📂 Belum ada akun panel yang terdaftar bray.`);
        }

        const list = panelUsers
          .map((u, i) => `${i + 1}. \`${u.username}\` ➜ role: \`${u.role}\` ➜ tg: \`${u.telegramId || "-"}\``)
          .join("\n");

        return send(chatId, `📂 **Daftar Akun Panel:**

${list}`);
      }
      
      if (text?.startsWith('/addprem')) {
        if (userId !== OWNER_ID && !ADMIN_IDS.includes(userId)) {
          await client.sendMessage(chatId, { 
            message: `🚫 **ACCESS DENIED**
────────────────────

❌ Akses ditolak!

Perintah **/addprem** khusus untuk Owner/Admin.

────────────────────

💡 __Hubungi owner jika perlu menambahkan user premium.__`,
            parseMode: "md"
          });
          return;
        }

        const args = text.split(' ');
        const targetId = args[1];
        const duration = args[2];

        if (!targetId || !duration || isNaN(duration) || parseInt(duration) <= 0) {
          await client.sendMessage(chatId, { 
            message: `❌ **INVALID FORMAT**
────────────────────

📋 **FORMAT PERINTAH**
├ /addprem [USER_ID] [HARI]
└ Contoh: \`/addprem 123456789 30\`

────────────────────

⚠️ **KETERANGAN**
├ 🆔 User ID : ID Telegram user
└ ⏱ Hari : Angka positif (1-365)

────────────────────

💡 __Contoh: /addprem 123456789 30 (30 hari premium)__`,
            parseMode: "md"
          });
          return;
        }

        const days = parseInt(duration);
        
        if (days > 365) {
          await client.sendMessage(chatId, { 
            message: `⚠️ **DURATION TOO LONG**
────────────────────

❌ Durasi maksimal premium adalah **365 hari** (1 tahun).

💡 __Masukkan durasi antara 1-365 hari.__`,
            parseMode: "md"
          });
          return;
        }

        const expiryDate = new Date();
        expiryDate.setDate(expiryDate.getDate() + days);
        const formattedExpiry = expiryDate.toLocaleDateString('id-ID', {
          day: 'numeric',
          month: 'long',
          year: 'numeric'
        });

        addPremiumUser(targetId, days);

        await client.sendMessage(chatId, { 
          message: `✅ **PREMIUM ADDED**
────────────────────

📊 **PREMIUM DETAILS**
├ 🆔 User ID : \`${targetId}\`
├ ⏱ Durasi : \`${days}\` Hari
├ 📅 Expired : \`${formattedExpiry}\`
└ 👤 Added by : \`${userId}\`

────────────────────

🎉 __User berhasil ditambahkan ke premium!__`,
          parseMode: "md"
        });

        try {
          await client.sendMessage(Number(targetId), { 
            message: `🎉 **PREMIUM ACCESS ACTIVATED**
────────────────────

Halo __Premium User__! 👋

Akun Anda telah diaktifkan sebagai **MEMBER PREMIUM** 🏆

────────────────────

📊 **PREMIUM DETAILS**
├ ⏱ Durasi : \`${days}\` Hari
├ 📅 Expired : \`${formattedExpiry}\`
└ 🎁 Status : \`ACTIVE\`

────────────────────

✨ **FITUR PREMIUM**
├ ✅ Build APK Tanpa Batas
├ ✅ Web to APK Unlimited
├ ✅ Prioritas Kompilasi
├ ✅ Support Lebih Cepat
└ ✅ Tanpa Iklan

────────────────────

💡 __Nikmati semua fitur tanpa batasan! Terima kasih telah menggunakan layanan kami.__`,
            parseMode: "md"
          });
        } catch (err) {
          console.log("Gagal ngabarin user via PM, mungkin bot di-block");
          await client.sendMessage(chatId, { 
            message: `⚠️ **WARNING**
────────────────────

✅ Premium berhasil ditambahkan, tapi **gagal mengirim notifikasi** ke user.

💡 __Kemungkinan user belum memulai chat dengan bot atau memblock bot.__`,
            parseMode: "md"
          });
        }
        return;
      }

      if (text === "/backup") {
        const msgId = event.message.id;
        try {
          await client.deleteMessages(chatId, [msgId], { revoke: true });
        } catch (_) {}
        return handleBackup(chatId, userId);
      }

      const isReportIntercepted = await handleUserReportMessages(event);
      if (isReportIntercepted) return;

      const job = getUserJob(userId);
      if (job?.type === "web2apk") {
        if (job.status === "waiting_url" && text?.startsWith("http"))
          return handleWeb2ApkUrl(event);
        if (job.status === "waiting_appname" && text)
          return handleWeb2ApkName(event);
        if (job.status === "waiting_icon" && msg.media)
          return handleWeb2ApkIcon(event);
      }

      if (msg.media) await handleZipFile(event);
    } catch (err) {
      console.error("Handler error:", err);
    }
  }, new NewMessage({}));

  client.addEventHandler(async (event) => {
    try {
      await handleCallback(event);
    } catch (err) {
      console.error("Callback error:", err);
    }
  }, new CallbackQuery({}));

  console.log(`🤖 ${CONFIG.BOT_NAME} v${CONFIG.BOT_VERSION} siap!`);
  await new Promise(() => {});
}

main().catch(console.error);